import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// API Health Check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Direct Zip Download endpoint
app.get(['/api/download-zip', '/download-code'], (_req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'public', 'banque-code-source.zip');
  res.download(zipPath, 'banque-code-source.zip', (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Erreur lors du téléchargement du fichier');
    }
  });
});

// Configure Vite in development or serve static in production
async function start() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n  🚀 AXO Banque est prête et démarrée avec succès !`);
    console.log(`  👉 Ouvrez votre navigateur sur : http://localhost:${PORT}`);
    console.log(`  ℹ️  Laissez ce terminal ouvert tant que vous utilisez l'application.\n`);
  });
}

start();
