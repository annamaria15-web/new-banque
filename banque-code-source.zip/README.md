# Application Bancaire AXO Banque (React + TypeScript)

Application bancaire complète développée avec **React**, **TypeScript**, **Vite** et **Tailwind CSS**.

---

## 💻 Guide d'utilisation dans Visual Studio Code (VS Code)

### Étape 1 : Extraire le fichier ZIP (Très important)
1. Téléchargez le fichier `banque-code-source.zip`.
2. **Ne l'ouvrez pas directement dans l'éditeur de texte de VS Code** (VS Code affichera un message indiquant que le fichier est binaire).
3. Cliquez avec le bouton droit sur le fichier ZIP :
   - Sur Windows : Cliquez sur **"Extraire tout..."**
   - Sur Mac : Double-cliquez sur le fichier ZIP pour le décompresser.
   - Sur Linux : Exécutez `unzip banque-code-source.zip`

### Étape 2 : Ouvrir le projet dans VS Code
1. Lancez **VS Code**.
2. Allez dans le menu en haut : **Fichier > Ouvrir le dossier...** (ou *File > Open Folder...*).
3. Sélectionnez le dossier extrait qui contient les fichiers `package.json`, `src/`, etc.

### Étape 3 : Installer les dépendances
1. Dans VS Code, ouvrez le terminal intégré : **Terminal > Nouveau terminal** (ou raccourci `Ctrl + \`` / `Cmd + \``).
2. Tapez la commande suivante puis appuyez sur Entrée :
```bash
npm install
```
*(Le fichier `.npmrc` inclus résout automatiquement les dépendances `npm` sans conflits).*

### Étape 4 : Démarrer le serveur de développement
Dans le même terminal, exécutez :
```bash
npm run dev
```

### Étape 5 : Ouvrir l'application
Dans votre navigateur (Chrome, Edge, Firefox), rendez-vous sur :
👉 **http://localhost:3000** (ou l'URL affichée dans votre terminal).

---

## 🛠️ Identifiants de test pour la connexion
- **Identifiant client :** `84920194`
- **Code secret PIN :** `123456`
*(Ou utilisez le bouton "Démo rapide" sur l'écran d'accueil)*

---

## 📁 Architecture du code
- `src/App.tsx` : Composant racine, routage des onglets, gestion de session et données.
- `src/components/` : Vues de l'application (Dashboard, Comptes, Virements, Épargne, Conseillère, Documents, Paramètres).
- `src/components/Footer.tsx` : Pied de page avec liens légaux et bouton de téléchargement direct **Code**.
- `src/components/modals/` : Modales (RIB officiel téléchargeable, virement instantané, plafonds CB, etc.).
- `src/data/mockData.ts` : Données bancaires initiales (comptes, cartes, historique, conseillère).
- `src/types.ts` : Types TypeScript complets du projet.
