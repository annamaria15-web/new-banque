export interface UserAccountProfile {
  id: string;
  fullName: string;
  clientId: string;
  pinCode?: string;
  createdAt: string;
  accountType?: string;
}

const LOCAL_USERS_KEY = 'banking_registered_clients';
const CURRENT_USER_KEY = 'banking_current_client_profile';

// Get local saved users
export function getLocalUsers(): UserAccountProfile[] {
  try {
    const raw = localStorage.getItem(LOCAL_USERS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// Save a local user profile
export function saveLocalUser(profile: UserAccountProfile) {
  try {
    const users = getLocalUsers();
    const existingIndex = users.findIndex(u => u.clientId === profile.clientId);
    if (existingIndex >= 0) {
      users[existingIndex] = profile;
    } else {
      users.push(profile);
    }
    localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(profile));
  } catch (err) {
    console.error('Erreur sauvegarde profil bancaire:', err);
  }
}

// Generate an 8-digit client ID
export function generateClientId(): string {
  return Math.floor(10000000 + Math.random() * 90000000).toString();
}

/**
 * Créer un compte bancaire avec nom, prénom et code secret (sans adresse email)
 */
export async function signUpAccount(
  fullName: string, 
  pinCode: string,
  accountType: string = 'Compte Courant Particulier'
): Promise<UserAccountProfile> {
  const cleanName = fullName.trim();
  const generatedId = generateClientId();

  const profile: UserAccountProfile = {
    id: `usr_${Date.now()}`,
    fullName: cleanName,
    clientId: generatedId,
    pinCode: pinCode.trim(),
    createdAt: new Date().toISOString(),
    accountType,
  };

  saveLocalUser(profile);
  localStorage.setItem('account_holder_name', cleanName);
  localStorage.setItem('saved_client_id', generatedId);

  return profile;
}

/**
 * Se connecter avec numéro client et code secret
 */
export async function signInWithClientId(
  clientId: string, 
  pinCode: string
): Promise<UserAccountProfile> {
  const cleanId = clientId.replace(/\s+/g, '');
  const cleanPin = pinCode.trim();

  // Check in local users registry
  const users = getLocalUsers();
  const found = users.find(u => u.clientId === cleanId);

  if (found) {
    // If the registered profile has a pinCode, verify it matches (if provided)
    if (found.pinCode && cleanPin && found.pinCode !== cleanPin) {
      throw new Error('Code secret erroné. Veuillez vérifier votre saisie.');
    }
    saveLocalUser(found);
    return found;
  }

  // Demo fallback for default or standard client ID
  const defaultHolder = localStorage.getItem('account_holder_name') || 'Jade Ambre';
  const fallbackProfile: UserAccountProfile = {
    id: `usr_demo_${cleanId}`,
    fullName: defaultHolder,
    clientId: cleanId || '84920194',
    pinCode: cleanPin || '123456',
    createdAt: new Date().toISOString(),
    accountType: 'Compte Courant Particulier',
  };

  saveLocalUser(fallbackProfile);
  return fallbackProfile;
}
