export type NavigationTab = 
  | 'dashboard' 
  | 'accounts' 
  | 'transfers' 
  | 'savings' 
  | 'loans' 
  | 'advisor' 
  | 'documents' 
  | 'settings';

export interface BankAccount {
  id: string;
  name: string;
  subtitle: string;
  type: 'checking' | 'savings' | 'pel';
  iban: string;
  maskedIban: string;
  bic: string;
  balance: number;
  availableBalance: number;
  rate?: number;
  isPrincipal?: boolean;
}

export interface BankTransaction {
  id: string;
  date: string;
  formattedDate: string;
  label: string;
  category: 'salary' | 'shopping' | 'transfer' | 'subscription' | 'cash' | 'bills' | 'health';
  amount: number;
  balanceAfter: number;
  type: 'credit' | 'debit';
  counterparty?: string;
  reference?: string;
}

export interface BankCard {
  id: string;
  type: string;
  network: 'VISA' | 'Mastercard' | 'CB / VISA' | 'CB / Mastercard';
  tier: 'Classic' | 'Premier';
  holder: string;
  maskedNumber: string;
  lastFour: string;
  expiry: string;
  cvv: string;
  isFrozen: boolean;
  contactlessEnabled: boolean;
  onlinePaymentsEnabled: boolean;
  abroadPaymentsEnabled: boolean;
  paymentLimitSpent: number;
  paymentLimitMax: number;
  withdrawalLimitSpent: number;
  withdrawalLimitMax: number;
  colorTheme: 'navy' | 'gold' | 'black';
}

export interface Beneficiary {
  id: string;
  name: string;
  nickname?: string;
  iban: string;
  bic: string;
  bankName: string;
  category: string;
  phone?: string;
  lastTransferDate?: string;
}

export interface AdvisorInfo {
  name: string;
  title: string;
  agency: string;
  agencyAddress: string;
  phone: string;
  email: string;
  avatarUrl: string;
  availableHours: string;
}

export interface BankDocument {
  id: string;
  title: string;
  category: 'statement' | 'rib' | 'tax' | 'contract' | 'notice';
  date: string;
  size: string;
  accountName: string;
}

export interface Loan {
  id: string;
  title: string;
  contractNumber: string;
  initialAmount: number;
  remainingAmount: number;
  monthlyPayment: number;
  interestRate: number;
  taeg: number;
  durationMonths: number;
  remainingMonths: number;
  nextPaymentDate: string;
  insuranceRate: number;
}
