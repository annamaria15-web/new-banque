import React, { useState } from 'react';
import { 
  CreditCard, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search, 
  Sliders, 
  Lock, 
  Unlock, 
  Wifi, 
  Globe, 
  Eye, 
  EyeOff, 
  Copy, 
  Check, 
  Filter, 
  FileDown
} from 'lucide-react';
import { BankAccount, BankCard, BankTransaction } from '../types';

interface AccountsViewProps {
  accounts: BankAccount[];
  transactions: BankTransaction[];
  cards: BankCard[];
  onOpenTransfer: (fromAccountId?: string) => void;
  onOpenRib: (account?: BankAccount) => void;
  onOpenCardLimits: (card?: BankCard) => void;
  onSelectTransaction: (tx: BankTransaction) => void;
  onUpdateCard: (updatedCard: BankCard) => void;
  accountHolder?: string;
}

export const AccountsView: React.FC<AccountsViewProps> = ({
  accounts,
  transactions,
  cards,
  onOpenTransfer,
  onOpenRib,
  onOpenCardLimits,
  onSelectTransaction,
  onUpdateCard,
  accountHolder = 'Titulaire du compte',
}) => {
  const [selectedAccountId, setSelectedAccountId] = useState(accounts[0].id);
  const [selectedCardId, setSelectedCardId] = useState(cards[0].id);
  const [showCardNumber, setShowCardNumber] = useState(false);
  const [copiedIban, setCopiedIban] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const selectedAccount = accounts.find(a => a.id === selectedAccountId) || accounts[0];
  const selectedCard = cards.find(c => c.id === selectedCardId) || cards[0];

  const handleCopyIban = (iban: string) => {
    navigator.clipboard.writeText(iban);
    setCopiedIban(true);
    setTimeout(() => setCopiedIban(false), 2000);
  };

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          tx.amount.toString().includes(searchTerm);
    const matchesCategory = categoryFilter === 'all' || tx.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const toggleCardFreeze = () => {
    onUpdateCard({
      ...selectedCard,
      isFrozen: !selectedCard.isFrozen,
    });
  };

  const toggleContactless = () => {
    onUpdateCard({
      ...selectedCard,
      contactlessEnabled: !selectedCard.contactlessEnabled,
    });
  };

  const toggleOnline = () => {
    onUpdateCard({
      ...selectedCard,
      onlinePaymentsEnabled: !selectedCard.onlinePaymentsEnabled,
    });
  };

  const toggleAbroad = () => {
    onUpdateCard({
      ...selectedCard,
      abroadPaymentsEnabled: !selectedCard.abroadPaymentsEnabled,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Comptes & Cartes
          </h1>
          <p className="text-sm text-slate-500">
            Consultez le solde de vos comptes et gérez les options de vos cartes bancaires.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenTransfer(selectedAccount.id)}
            className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
          >
            Nouveau virement
          </button>
          <button
            onClick={() => onOpenRib(selectedAccount)}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl transition-all"
          >
            Télécharger RIB
          </button>
        </div>
      </div>

      {/* Account Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {accounts.map(acc => {
          const isSelected = acc.id === selectedAccountId;
          return (
            <div
              key={acc.id}
              onClick={() => setSelectedAccountId(acc.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer relative ${
                isSelected
                  ? 'bg-blue-900 text-white border-blue-950 shadow-md ring-2 ring-blue-700/50'
                  : 'bg-white text-slate-800 border-slate-200/90 hover:border-blue-300 hover:shadow-sm'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-2">
                <span className={`font-semibold ${isSelected ? 'text-blue-200' : 'text-slate-500'}`}>
                  {acc.isPrincipal ? 'Compte courant' : 'Épargne'}
                </span>
                {acc.rate && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isSelected ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-700'}`}>
                    {acc.rate}%
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm tracking-tight truncate">{acc.name}</h3>
              <p className={`text-xl font-extrabold mt-2 ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                {acc.balance.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
              </p>
              <div className="mt-2 text-[11px] font-mono opacity-80 truncate">
                {acc.maskedIban}
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Grid: Card & Controls (Left) + Operations History (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Card Management & Settings */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900">
                Carte rattachée
              </h2>
              <div className="flex gap-1.5">
                {cards.map(card => (
                  <button
                    key={card.id}
                    onClick={() => setSelectedCardId(card.id)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                      selectedCardId === card.id 
                        ? 'bg-[#0f3d7d] text-white' 
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {card.tier}
                  </button>
                ))}
              </div>
            </div>

            {/* Realistic Bank Card */}
            <div className={`relative w-full aspect-[1.586/1] rounded-2xl p-5 text-white shadow-xl overflow-hidden select-none transition-all ${
              selectedCard.isFrozen 
                ? 'bg-slate-700 grayscale' 
                : selectedCard.tier === 'Premier'
                ? 'bg-gradient-to-tr from-[#997327] via-[#c9a347] to-[#755519]'
                : 'bg-gradient-to-tr from-[#0a182d] via-[#102a52] to-[#0c1f3a]'
            }`}>
              {/* Frozen Overlay */}
              {selectedCard.isFrozen && (
                <div className="absolute inset-0 bg-slate-950/70 z-20 flex flex-col items-center justify-center text-white backdrop-blur-[2px]">
                  <Lock className="w-8 h-8 text-rose-400 mb-1" />
                  <span className="font-bold text-sm tracking-wider uppercase">Carte temporairement verrouillée</span>
                  <span className="text-xs text-slate-300">Paiements et retraits désactivés</span>
                </div>
              )}

              {/* Card Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-xs tracking-tight text-white/90">
                    Carte Particulier
                  </span>
                </div>

                {/* EMV Chip and contactless indicator */}
                <div className="flex items-center gap-2">
                  <div className="w-6 h-4 rounded bg-gradient-to-br from-amber-200 to-amber-400 border border-amber-500/50 flex items-center justify-center">
                    <div className="w-2.5 h-1.5 border border-amber-700/30" />
                  </div>
                  {selectedCard.contactlessEnabled && (
                    <Wifi className="w-4 h-4 rotate-90 opacity-80" />
                  )}
                  <span className="text-xs font-medium tracking-wider uppercase opacity-90">
                    {selectedCard.tier}
                  </span>
                </div>
              </div>

              {/* Card Number & Reveal Button */}
              <div className="mt-5 mb-1 flex items-center justify-between">
                <div className="font-mono text-base tracking-[0.25em] text-white">
                  {showCardNumber ? '4970 8821 4410 ' + selectedCard.lastFour : `•••• •••• •••• ${selectedCard.lastFour}`}
                </div>
                <button
                  onClick={() => setShowCardNumber(!showCardNumber)}
                  className="p-1.5 hover:bg-white/20 rounded-lg text-white/80 transition-colors"
                  title={showCardNumber ? "Masquer le numéro" : "Afficher le numéro"}
                >
                  {showCardNumber ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Legal French Card mention */}
              <div className="text-[9px] font-bold text-amber-200/90 tracking-widest uppercase mb-1">
                DÉBIT IMMÉDIAT
              </div>

              {/* Card Footer: Expiry, CVV & Dual CB / VISA Brand */}
              <div className="flex items-end justify-between mt-auto">
                <div className="flex gap-4 items-end">
                  <div>
                    <p className="text-[9px] text-slate-300 uppercase tracking-widest">Titulaire</p>
                    <p className="font-mono text-xs font-semibold uppercase truncate max-w-[140px]">{accountHolder}</p>
                  </div>
                  <div>
                    <p className="text-[9px] text-slate-300 uppercase tracking-widest">Expire fin</p>
                    <p className="font-mono text-xs font-semibold">{selectedCard.expiry}</p>
                  </div>
                  <div>
                    <p className="text-[9px] text-slate-300 uppercase tracking-widest">CVV</p>
                    <p className="font-mono text-xs font-semibold">{showCardNumber ? selectedCard.cvv : '•••'}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="bg-[#00704a] text-white font-extrabold text-[10px] px-1.5 py-0.5 rounded tracking-wider flex items-center shadow-xs border border-emerald-400/40">
                    CB
                  </div>
                  <span className="font-black italic text-xl tracking-wider text-white">
                    VISA
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Limit Progress Bar */}
            <div className="mt-5 space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Plafond de paiements (30j)</span>
                  <span className="font-bold text-slate-800">
                    {selectedCard.paymentLimitSpent} € / {selectedCard.paymentLimitMax} €
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-700 rounded-full transition-all"
                    style={{ width: `${(selectedCard.paymentLimitSpent / selectedCard.paymentLimitMax) * 100}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Plafond de retraits (7j)</span>
                  <span className="font-bold text-slate-800">
                    {selectedCard.withdrawalLimitSpent} € / {selectedCard.withdrawalLimitMax} €
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-600 rounded-full transition-all"
                    style={{ width: `${(selectedCard.withdrawalLimitSpent / selectedCard.withdrawalLimitMax) * 100}%` }}
                  />
                </div>
              </div>

              <button
                onClick={() => onOpenCardLimits(selectedCard)}
                className="w-full mt-2 py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Modifier les plafonds</span>
              </button>
            </div>

            {/* Security Toggles */}
            <div className="mt-5 pt-4 border-t border-slate-100 space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Sécurité & Options
              </h3>

              {/* Freeze Toggle */}
              <div className="flex items-center justify-between py-1">
                <div className="flex items-center gap-2.5">
                  {selectedCard.isFrozen ? (
                    <Lock className="w-4 h-4 text-rose-600" />
                  ) : (
                    <Unlock className="w-4 h-4 text-emerald-600" />
                  )}
                  <div>
                    <p className="text-xs font-semibold text-slate-800">Verrouillage temporaire</p>
                    <p className="text-[11px] text-slate-400">Bloquez la carte en un clic</p>
                  </div>
                </div>
                <button
                  onClick={toggleCardFreeze}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    selectedCard.isFrozen ? 'bg-rose-600' : 'bg-slate-300'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    selectedCard.isFrozen ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {/* Contactless Toggle */}
              <div className="flex items-center justify-between py-1">
                <div className="flex items-center gap-2.5">
                  <Wifi className="w-4 h-4 text-blue-600 rotate-90" />
                  <div>
                    <p className="text-xs font-semibold text-slate-800">Paiement sans contact</p>
                    <p className="text-[11px] text-slate-400">Jusqu'à 50 € par paiement</p>
                  </div>
                </div>
                <button
                  onClick={toggleContactless}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    selectedCard.contactlessEnabled ? 'bg-blue-700' : 'bg-slate-300'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    selectedCard.contactlessEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {/* Online Payments Toggle */}
              <div className="flex items-center justify-between py-1">
                <div className="flex items-center gap-2.5">
                  <Globe className="w-4 h-4 text-blue-600" />
                  <div>
                    <p className="text-xs font-semibold text-slate-800">Paiements sur Internet</p>
                    <p className="text-[11px] text-slate-400">Achats sécurisés 3D-Secure</p>
                  </div>
                </div>
                <button
                  onClick={toggleOnline}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    selectedCard.onlinePaymentsEnabled ? 'bg-blue-700' : 'bg-slate-300'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    selectedCard.onlinePaymentsEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Full Operations & History Table */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Historique des opérations
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {selectedAccount.name} ({selectedAccount.maskedIban})
                </p>
              </div>

              {/* Search in operations */}
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Filtrer les opérations..."
                    className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 w-44"
                  />
                </div>
              </div>
            </div>

            {/* Categories filter pills */}
            <div className="flex items-center gap-1.5 py-3 overflow-x-auto text-[11px]">
              {['all', 'salary', 'shopping', 'transfer', 'bills', 'subscription', 'cash'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-full font-medium transition-colors ${
                    categoryFilter === cat
                      ? 'bg-blue-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat === 'all' ? 'Toutes' : cat === 'salary' ? 'Salaires' : cat === 'shopping' ? 'Achats' : cat === 'transfer' ? 'Virements' : cat === 'bills' ? 'Factures' : cat === 'subscription' ? 'Abonnements' : 'Retraits'}
                </button>
              ))}
            </div>

            {/* Operations list */}
            <div className="divide-y divide-slate-100">
              {filteredTransactions.map((tx) => {
                const isCredit = tx.amount > 0;
                return (
                  <div
                    key={tx.id}
                    onClick={() => onSelectTransaction(tx)}
                    className="py-3 px-2 flex items-center justify-between hover:bg-slate-50/80 rounded-xl transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                        isCredit 
                          ? 'bg-emerald-50 text-emerald-600' 
                          : 'bg-slate-100 text-slate-600'
                      }`}>
                        {isCredit ? (
                          <ArrowDownLeft className="w-4 h-4" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 group-hover:text-blue-700 transition-colors">
                          {tx.label}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          {tx.formattedDate} • Ref: {tx.reference || 'N/A'}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className={`text-xs font-bold ${isCredit ? 'text-emerald-600' : 'text-slate-900'}`}>
                        {isCredit ? `+ ${tx.amount.toFixed(2)} €` : `${tx.amount.toFixed(2)} €`}
                      </p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        Solde : {tx.balanceAfter.toFixed(2)} €
                      </p>
                    </div>
                  </div>
                );
              })}

              {filteredTransactions.length === 0 && (
                <div className="text-center py-10 text-slate-400 text-xs">
                  Aucune opération trouvée avec ces critères.
                </div>
              )}
            </div>
          </div>

          {/* Export link */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Affichage de {filteredTransactions.length} opérations</span>
            <button
              onClick={() => onOpenRib(selectedAccount)}
              className="text-blue-700 hover:text-blue-900 font-semibold flex items-center gap-1.5"
            >
              <FileDown className="w-3.5 h-3.5" /> Exporter en PDF / CSV
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
