import React, { useState, useEffect } from 'react';
import { 
  Lock, 
  ShieldCheck, 
  KeyRound, 
  AlertCircle, 
  CheckCircle2, 
  Headphones, 
  Shield, 
  ArrowRight, 
  User as UserIcon,
  Eye,
  EyeOff,
  UserPlus,
  Sparkles,
  CreditCard,
  Check
} from 'lucide-react';
import { 
  signUpAccount, 
  signInWithClientId 
} from '../services/authService';

interface LoginViewProps {
  onLogin: (clientId: string, holderName: string) => void;
  justLoggedOut?: boolean;
  onOpenHelp: () => void;
  initialHolderName?: string;
  onOpenDownload?: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLogin,
  justLoggedOut = false,
  onOpenHelp,
  initialHolderName = 'Jade Ambre',
  onOpenDownload,
}) => {
  // Main view mode: 'login' or 'register'
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');

  // Login Form States: field is empty by default so placeholder "Ex : Jade Ambre" is cleanly visible without pre-filled text
  const [holderName, setHolderName] = useState<string>('');
  const [clientId, setClientId] = useState(() => {
    return localStorage.getItem('saved_client_id') || '84920194';
  });
  const [rememberMe, setRememberMe] = useState(true);
  const [pinCode, setPinCode] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [useVirtualKeyboard, setUseVirtualKeyboard] = useState(false);
  const [keypadNumbers, setKeypadNumbers] = useState<number[]>([]);

  // Register Form States
  const [regFullName, setRegFullName] = useState('');
  const [regPin, setRegPin] = useState('');
  const [regConfirmPin, setRegConfirmPin] = useState('');
  const [showRegPin, setShowRegPin] = useState(false);
  const [regAccountType, setRegAccountType] = useState('Compte Courant Essentiel');
  const [acceptTerms, setAcceptTerms] = useState(true);

  // Common States
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showForgotModal, setShowForgotModal] = useState<'id' | 'pin' | null>(null);

  // Generate scrambled keypad for traditional client ID banking
  const shuffleKeypad = () => {
    const nums = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    for (let i = nums.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [nums[i], nums[j]] = [nums[j], nums[i]];
    }
    setKeypadNumbers(nums);
  };

  useEffect(() => {
    shuffleKeypad();
    // Clean any legacy saved holder name containing old values
    try {
      const saved = localStorage.getItem('account_holder_name');
      if (saved && /kouam|koum|christ/i.test(saved)) {
        localStorage.setItem('account_holder_name', 'Jade Ambre');
      }
    } catch {}
  }, []);

  const handleKeypadPress = (num: number) => {
    if (pinCode.length < 6) {
      setPinCode(prev => prev + num.toString());
      setErrorMessage(null);
    }
  };

  const handleBackspace = () => {
    setPinCode(prev => prev.slice(0, -1));
    setErrorMessage(null);
  };

  // Handle Login submission
  const handleLoginSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanName = holderName.trim() || 'Jade Ambre';
    const cleanId = clientId.replace(/\s+/g, '') || '84920194';

    if (!cleanId || cleanId.length < 6) {
      setErrorMessage('Veuillez saisir un identifiant client valide (au moins 6 chiffres).');
      return;
    }
    if (pinCode.length < 6) {
      setErrorMessage('Veuillez composer votre code secret complet à 6 chiffres.');
      return;
    }

    setIsLoading(true);
    localStorage.setItem('account_holder_name', cleanName);
    if (rememberMe) {
      localStorage.setItem('saved_client_id', cleanId);
    } else {
      localStorage.removeItem('saved_client_id');
    }

    try {
      const userProfile = await signInWithClientId(cleanId, pinCode);
      setSuccessMessage(`Connexion réussie ! Bienvenue ${userProfile.fullName}`);
      setTimeout(() => {
        setIsLoading(false);
        onLogin(userProfile.clientId, userProfile.fullName);
      }, 500);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err?.message || 'Identifiants ou code secret incorrect.');
    }
  };

  // Handle Register submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanName = regFullName.trim();

    if (!cleanName || cleanName.length < 2) {
      setErrorMessage('Veuillez indiquer vos nom et prénom complets.');
      return;
    }
    if (!regPin || regPin.length < 6) {
      setErrorMessage('Le code secret doit comporter exactement 6 chiffres.');
      return;
    }
    if (regPin !== regConfirmPin) {
      setErrorMessage('Les deux codes secrets saisis ne correspondent pas.');
      return;
    }
    if (!acceptTerms) {
      setErrorMessage('Veuillez accepter les conditions d\'ouverture de compte.');
      return;
    }

    setIsLoading(true);

    try {
      const newProfile = await signUpAccount(cleanName, regPin, regAccountType);
      setSuccessMessage(`Félicitations ${cleanName} ! Votre compte est ouvert. N° Client : ${newProfile.clientId}`);

      setTimeout(() => {
        setIsLoading(false);
        onLogin(newProfile.clientId, newProfile.fullName);
      }, 800);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err?.message || 'Erreur lors de l\'ouverture du compte. Veuillez réessayer.');
    }
  };

  // Demo Fast Login
  const handleDemoLogin = () => {
    setClientId('84920194');
    setPinCode('123456');
    setHolderName('Jade Ambre');
    localStorage.setItem('account_holder_name', 'Jade Ambre');
    localStorage.setItem('saved_client_id', '84920194');
    setIsLoading(true);
    setSuccessMessage('Connexion démo sécurisée en cours...');
    setTimeout(() => {
      setIsLoading(false);
      onLogin('84920194', 'Jade Ambre');
    }, 400);
  };

  return (
    <div className="min-h-[calc(100vh-180px)] py-8 px-4 sm:px-6 lg:px-8 flex items-center justify-center bg-slate-50/70">
      <div className="w-full max-w-lg space-y-6">

        {/* Successful Logout Banner */}
        {justLoggedOut && (
          <div className="bg-emerald-50 border border-emerald-200/90 rounded-2xl p-4 text-xs text-emerald-900 shadow-sm flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Déconnexion réussie</p>
              <p className="text-emerald-700 text-[11px] mt-0.5 leading-relaxed">
                Votre session sécurisée a été clôturée avec succès. Vous pouvez vous reconnecter à tout moment.
              </p>
            </div>
          </div>
        )}

        {/* Main Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xl shadow-slate-200/50 space-y-6">
          
          {/* Card Top Header */}
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-50 text-[#0f3d7d] rounded-2xl flex items-center justify-center mx-auto mb-3 border border-blue-100/80 shadow-xs">
              <Lock className="w-6 h-6 text-[#0f3d7d]" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Espace Client Sécurisé
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Plateforme bancaire certifiée ACPR & DSP2
            </p>
          </div>

          {/* Main Switch: Se connecter VS Créer un compte */}
          <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200/80">
            <button
              type="button"
              onClick={() => {
                setActiveTab('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
                activeTab === 'login'
                  ? 'bg-white text-[#0f3d7d] shadow-sm font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Se connecter</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('register');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
                activeTab === 'register'
                  ? 'bg-white text-emerald-800 shadow-sm font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-600" />
              <span>Créer un compte</span>
            </button>
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 border border-rose-200/90 rounded-2xl text-xs text-rose-800 flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span className="leading-relaxed font-medium">{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200/90 rounded-2xl text-xs text-emerald-900 flex items-center gap-2.5 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-bold">{successMessage}</span>
            </div>
          )}

          {/* ============================================================== */}
          {/* TAB 1: SE CONNECTER                                            */}
          {/* ============================================================== */}
          {activeTab === 'login' && (
            <div className="space-y-5 animate-in fade-in">
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                
                {/* Holder Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Titulaire du compte
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={holderName}
                      onChange={(e) => setHolderName(e.target.value)}
                      placeholder="Ex : Jade Ambre"
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 text-slate-900 font-medium"
                    />
                  </div>
                </div>

                {/* Client ID */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Identifiant Client (8 chiffres)
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowForgotModal('id')}
                      className="text-[11px] text-blue-800 hover:text-blue-900 font-semibold"
                    >
                      Où le trouver ?
                    </button>
                  </div>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      maxLength={12}
                      value={clientId}
                      onChange={(e) => setClientId(e.target.value)}
                      placeholder="Ex : 84920194"
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs font-mono font-bold tracking-wider bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 text-slate-900"
                    />
                  </div>
                </div>

                {/* Secret PIN (6 digits) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Code secret (6 chiffres)
                    </label>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setUseVirtualKeyboard(!useVirtualKeyboard)}
                        className="text-[11px] text-[#0f3d7d] hover:underline font-semibold"
                      >
                        {useVirtualKeyboard ? 'Saisie clavier' : 'Clavier virtuel'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowForgotModal('pin')}
                        className="text-[11px] text-blue-800 hover:text-blue-900 font-semibold"
                      >
                        Code oublié ?
                      </button>
                    </div>
                  </div>

                  {!useVirtualKeyboard ? (
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPin ? "text" : "password"}
                        maxLength={6}
                        value={pinCode}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, '');
                          if (val.length <= 6) setPinCode(val);
                        }}
                        placeholder="••••••"
                        className="w-full pl-10 pr-10 py-2.5 text-xs font-mono font-bold tracking-widest bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 text-slate-900"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPin(!showPin)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  ) : (
                    /* DSP2 Scrambled Virtual Keypad */
                    <div className="space-y-2">
                      <div className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2">
                        <div className="flex items-center gap-1.5">
                          {[0, 1, 2, 3, 4, 5].map((i) => (
                            <span 
                              key={i} 
                              className={`w-3 h-3 rounded-full transition-all ${
                                i < pinCode.length 
                                  ? 'bg-[#0f3d7d] scale-110' 
                                  : 'bg-slate-200'
                              }`} 
                            />
                          ))}
                        </div>
                        <button
                          type="button"
                          onClick={handleBackspace}
                          disabled={pinCode.length === 0}
                          className="text-[11px] font-bold text-slate-500 hover:text-slate-800 disabled:opacity-40"
                        >
                          Effacer
                        </button>
                      </div>

                      <div className="grid grid-cols-5 gap-1.5 p-2 bg-slate-100/70 border border-slate-200 rounded-2xl">
                        {keypadNumbers.map((num) => (
                          <button
                            key={num}
                            type="button"
                            onClick={() => handleKeypadPress(num)}
                            className="h-10 bg-white hover:bg-blue-50 active:bg-blue-100 text-slate-800 font-bold text-sm rounded-xl border border-slate-200/90 shadow-2xs transition-all active:scale-95 flex items-center justify-center font-mono"
                          >
                            {num}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Remember Me Checkbox */}
                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 text-[#0f3d7d] border-slate-300 rounded focus:ring-blue-600"
                    />
                    <span>Mémoriser mon identifiant</span>
                  </label>
                  <span className="text-[11px] text-slate-400">Connexion sécurisée SSL</span>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 bg-[#0f3d7d] hover:bg-[#0c2f61] disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Accéder à mes comptes</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* Fast Demo Access Button */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="w-full py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Connexion Rapide (Mode Démo — 1 clic)</span>
                </button>
              </div>

              {/* Switch to Register callout */}
              <p className="text-center text-xs text-slate-500 pt-1">
                Pas encore client ?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('register');
                    setErrorMessage(null);
                  }}
                  className="text-[#0f3d7d] font-bold hover:underline"
                >
                  Devenir client en 2 minutes
                </button>
              </p>
            </div>
          )}

          {/* ============================================================== */}
          {/* TAB 2: CRÉER UN COMPTE BANCAIRE (NOUVEAU CLIENT)               */}
          {/* ============================================================== */}
          {activeTab === 'register' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-2xl p-3.5 text-xs text-emerald-900 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Ouverture de compte immédiate</p>
                  <p className="text-[11px] text-emerald-700 mt-0.5">
                    Renseignez vos informations ci-dessous. Votre N° client et vos accès sécurisés seront générés instantanément.
                  </p>
                </div>
              </div>

              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nom et Prénom du titulaire *
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      placeholder="Ex : Jade Ambre"
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 text-slate-900 font-medium"
                    />
                  </div>
                </div>

                {/* Account Type Choice */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Formule de compte souhaitée
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setRegAccountType('Compte Courant Essentiel')}
                      className={`p-2.5 rounded-xl border text-left transition-all text-xs ${
                        regAccountType === 'Compte Courant Essentiel'
                          ? 'border-emerald-600 bg-emerald-50/50 ring-1 ring-emerald-600 font-bold text-emerald-950'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-bold text-xs">Essentiel</span>
                        <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                      </div>
                      <p className="text-[10px] text-slate-500 font-normal">Carte VISA Classic incluse</p>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRegAccountType('Formule Gold Premier')}
                      className={`p-2.5 rounded-xl border text-left transition-all text-xs ${
                        regAccountType === 'Formule Gold Premier'
                          ? 'border-emerald-600 bg-emerald-50/50 ring-1 ring-emerald-600 font-bold text-emerald-950'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-bold text-xs">Gold Premier</span>
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      </div>
                      <p className="text-[10px] text-slate-500 font-normal">Plafonds étendus & Assurances</p>
                    </button>
                  </div>
                </div>

                {/* Secret PIN choice */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Code secret (6 chiffres) *
                    </label>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type={showRegPin ? "text" : "password"}
                        required
                        maxLength={6}
                        value={regPin}
                        onChange={(e) => setRegPin(e.target.value.replace(/\D/g, ''))}
                        placeholder="••••••"
                        className="w-full pl-9 pr-8 py-2 text-xs font-mono font-bold tracking-widest bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 text-slate-900"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegPin(!showRegPin)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {showRegPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Confirmer le code *
                    </label>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type={showRegPin ? "text" : "password"}
                        required
                        maxLength={6}
                        value={regConfirmPin}
                        onChange={(e) => setRegConfirmPin(e.target.value.replace(/\D/g, ''))}
                        placeholder="••••••"
                        className="w-full pl-9 pr-3 py-2 text-xs font-mono font-bold tracking-widest bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 text-slate-900"
                      />
                    </div>
                  </div>
                </div>

                {/* Terms checkbox */}
                <div className="pt-1">
                  <label className="flex items-start gap-2 cursor-pointer select-none text-[11px] text-slate-600">
                    <input
                      type="checkbox"
                      checked={acceptTerms}
                      onChange={(e) => setAcceptTerms(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500 mt-0.5"
                    />
                    <span>
                      J'accepte la convention d'ouverture de compte et la protection des données (RGPD).
                    </span>
                  </label>
                </div>

                {/* Submit Register */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 mt-2"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Ouvrir mon compte bancaire</span>
                      <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* Back to Login */}
              <p className="text-center text-xs text-slate-500 pt-2">
                Vous possédez déjà un identifiant ?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('login');
                    setErrorMessage(null);
                  }}
                  className="text-[#0f3d7d] font-bold hover:underline"
                >
                  Se connecter
                </button>
              </p>
            </div>
          )}

          {/* Footer Security Badges */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span className="flex items-center gap-1.5 text-slate-600 font-medium">
              <Shield className="w-3.5 h-3.5 text-emerald-600" />
              Agrément Banque de France n° 30004
            </span>
            <button
              onClick={onOpenHelp}
              className="flex items-center gap-1 text-[#0f3d7d] hover:underline font-semibold"
            >
              <Headphones className="w-3.5 h-3.5" />
              Assistance 24/7
            </button>
          </div>

        </div>

      </div>

      {/* Forgot Client ID / PIN Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="font-bold text-slate-900 text-sm">
                {showForgotModal === 'id' ? "Retrouver mon identifiant client" : "Code secret oublié"}
              </h3>
              <button 
                onClick={() => setShowForgotModal(null)} 
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            {showForgotModal === 'id' ? (
              <div className="space-y-2 text-slate-600 leading-relaxed">
                <p>
                  Votre identifiant client comporte <strong>8 chiffres</strong>. Vous pouvez le retrouver facilement :
                </p>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>En haut à gauche de tous vos <strong>relevés de compte bancaire</strong>.</li>
                  <li>Sur la lettre de bienvenue remise à l'ouverture de compte.</li>
                  <li>Sur votre contrat d'ouverture de compte.</li>
                </ul>
                <div className="bg-blue-50 p-2.5 rounded-xl border border-blue-100 text-blue-900 text-[11px]">
                  <strong>Identifiant de démonstration :</strong> <code className="font-mono font-bold">84920194</code>
                </div>
              </div>
            ) : (
              <div className="space-y-2 text-slate-600 leading-relaxed">
                <p>
                  Pour des raisons de sécurité DSP2, votre code secret est strictement confidentiel.
                </p>
                <p className="text-[11px]">
                  En cas d'oubli, contactez votre conseiller dédié au <strong>01 45 67 89 10</strong> (gratuit 24h/24).
                </p>
                <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-100 text-emerald-900 text-[11px]">
                  <strong>Code secret de démonstration :</strong> <code className="font-mono font-bold">123456</code>
                </div>
              </div>
            )}

            <button
              onClick={() => setShowForgotModal(null)}
              className="w-full py-2 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors"
            >
              Compris
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
