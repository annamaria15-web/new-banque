import React, { useState } from 'react';
import { 
  Send, 
  UserPlus, 
  Zap, 
  Calendar, 
  CheckCircle2, 
  ArrowRight, 
  Clock, 
  Search, 
  ShieldCheck
} from 'lucide-react';
import { BankAccount, Beneficiary } from '../types';

interface TransfersViewProps {
  accounts: BankAccount[];
  beneficiaries: Beneficiary[];
  onOpenBeneficiaryModal: () => void;
  onExecuteTransfer: (data: {
    fromAccountId: string;
    toIban: string;
    beneficiaryName: string;
    amount: number;
    instant: boolean;
    reason: string;
  }) => void;
  accountHolder?: string;
}

export const TransfersView: React.FC<TransfersViewProps> = ({
  accounts,
  beneficiaries,
  onOpenBeneficiaryModal,
  onExecuteTransfer,
  accountHolder = 'Titulaire du compte',
}) => {
  const [fromAccountId, setFromAccountId] = useState(accounts[0]?.id || '');
  const [selectedBenId, setSelectedBenId] = useState(beneficiaries[0]?.id || '');
  const [amount, setAmount] = useState<string>('');
  const [isInstant, setIsInstant] = useState(true);
  const [reason, setReason] = useState('');
  const [transferSuccess, setTransferSuccess] = useState(false);
  const [lastTransferDetails, setLastTransferDetails] = useState<any>(null);
  const [beneficiarySearch, setBeneficiarySearch] = useState('');

  const selectedAccount = accounts.find(a => a.id === fromAccountId) || accounts[0];
  const selectedBeneficiary = beneficiaries.find(b => b.id === selectedBenId) || beneficiaries[0];

  const numAmount = parseFloat(amount.replace(',', '.')) || 0;
  const isBalanceSufficient = selectedAccount ? selectedAccount.balance >= numAmount : false;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBeneficiary || numAmount <= 0 || !isBalanceSufficient) return;

    const ref = `VIR-SEPA-${Date.now().toString().slice(-6)}`;

    onExecuteTransfer({
      fromAccountId: selectedAccount.id,
      toIban: selectedBeneficiary.iban,
      beneficiaryName: selectedBeneficiary.name,
      amount: numAmount,
      instant: isInstant,
      reason: reason || 'Virement ponctuel',
    });

    setLastTransferDetails({
      fromName: selectedAccount.name,
      toName: selectedBeneficiary.name,
      toIban: selectedBeneficiary.iban,
      amount: numAmount,
      instant: isInstant,
      date: new Date().toLocaleDateString('fr-FR'),
      reason: reason || 'Virement ponctuel',
      reference: ref,
    });

    setTransferSuccess(true);
    setAmount('');
    setReason('');
  };

  const filteredBeneficiaries = beneficiaries.filter(b => 
    b.name.toLowerCase().includes(beneficiarySearch.toLowerCase()) ||
    b.iban.toLowerCase().includes(beneficiarySearch.toLowerCase()) ||
    (b.nickname && b.nickname.toLowerCase().includes(beneficiarySearch.toLowerCase()))
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Virements & Opérations
          </h1>
          <p className="text-sm text-slate-500">
            Effectuez des virements instantanés ou différés et gérez vos bénéficiaires enregistrés.
          </p>
        </div>

        <button
          onClick={onOpenBeneficiaryModal}
          className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Ajouter un bénéficiaire</span>
        </button>
      </div>

      {/* Main Grid: Transfer Form (Left 7) + Beneficiaries & Scheduled (Right 5) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Transfer Form Box */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm">
          {transferSuccess ? (
            <div className="py-8 text-center space-y-4 animate-in fade-in">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                Virement effectué avec succès !
              </h2>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                Votre virement de <strong className="text-slate-900">{lastTransferDetails?.amount?.toFixed(2)} €</strong> vers <strong className="text-slate-900">{lastTransferDetails?.toName}</strong> a été exécuté {lastTransferDetails?.instant ? 'instantanément' : 'en mode standard'}.
              </p>

              <div className="bg-slate-50 p-4 rounded-xl max-w-md mx-auto text-left text-xs space-y-1.5 border border-slate-100">
                <div className="flex justify-between text-slate-500">
                  <span>Compte débité :</span>
                  <span className="font-semibold text-slate-800">{lastTransferDetails?.fromName}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Bénéficiaire :</span>
                  <span className="font-semibold text-slate-800">{lastTransferDetails?.toName}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Motif :</span>
                  <span className="font-semibold text-slate-800">{lastTransferDetails?.reason}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Type d'envoi :</span>
                  <span className="font-semibold text-emerald-600">
                    {lastTransferDetails?.instant ? 'Instantané (0,00 € gratuit)' : 'Standard'}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500 pt-1 border-t border-slate-200/60">
                  <span>Référence SEPA :</span>
                  <span className="font-mono text-slate-700">{lastTransferDetails?.reference}</span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={() => setTransferSuccess(false)}
                  className="px-6 py-2.5 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl transition-all shadow-sm"
                >
                  Effectuer un autre virement
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Send className="w-4 h-4 text-blue-700 rotate-[-20deg]" />
                Émettre un virement
              </h2>

              {/* Source Account */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Compte à débiter
                </label>
                <select
                  value={fromAccountId}
                  onChange={(e) => setFromAccountId(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 font-medium text-slate-800"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} — Solde : {acc.balance.toFixed(2)} € ({acc.maskedIban})
                    </option>
                  ))}
                </select>
              </div>

              {/* Beneficiary Target */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700">
                    Bénéficiaire crédité
                  </label>
                  <button
                    type="button"
                    onClick={onOpenBeneficiaryModal}
                    className="text-xs text-[#0f3d7d] hover:underline font-semibold flex items-center gap-1"
                  >
                    + Nouveau
                  </button>
                </div>
                <select
                  value={selectedBenId}
                  onChange={(e) => setSelectedBenId(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 font-medium text-slate-800"
                >
                  {beneficiaries.map(ben => (
                    <option key={ben.id} value={ben.id}>
                      {ben.name} ({ben.nickname || ben.bankName}) — {ben.iban.slice(0, 14)}...
                    </option>
                  ))}
                </select>
              </div>

              {/* Amount & Quick Chips */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Montant en euros (€)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full p-3 text-lg font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 text-slate-900 pr-10"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-base">
                    €
                  </span>
                </div>

                {numAmount > 0 && !isBalanceSufficient && (
                  <p className="text-xs text-rose-600 mt-1 font-medium">
                    Solde disponible insuffisant pour ce montant.
                  </p>
                )}

                {/* Quick amount chips */}
                <div className="flex items-center gap-2 mt-2">
                  {[20, 50, 100, 250, 500].map(val => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setAmount(val.toString())}
                      className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors"
                    >
                      {val} €
                    </button>
                  ))}
                </div>
              </div>

              {/* Instant vs Standard */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div
                  onClick={() => setIsInstant(true)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    isInstant 
                      ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-600' 
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Zap className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold text-slate-900">Virement instantané</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Fonds reçus en 10 secondes, disponible 24h/24 et 7j/7. Gratuit.
                  </p>
                </div>

                <div
                  onClick={() => setIsInstant(false)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    !isInstant 
                      ? 'border-blue-700 bg-blue-50/70 ring-1 ring-blue-700' 
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-slate-900">Virement standard</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Délai bancaire standard de 1 à 2 jours ouvrés.
                  </p>
                </div>
              </div>

              {/* Reason / Reference */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Motif du virement (facultatif)
                </label>
                <input
                  type="text"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Ex : Remboursement restaurant, Loyer..."
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 text-slate-800"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs text-slate-600">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Opération certifiée DSP2 & Garantie des Dépôts
                </span>
                <span className="font-semibold text-emerald-700 text-[11px]">Sans frais</span>
              </div>

              <button
                type="submit"
                disabled={numAmount <= 0 || !isBalanceSufficient}
                className="w-full py-3 bg-[#0f3d7d] hover:bg-[#0c2f61] disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>Confirmer et exécuter le virement</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

        {/* Right side: Beneficiaries & Scheduled transfers */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Beneficiaries Directory */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-900">
                Bénéficiaires enregistrés ({beneficiaries.length})
              </h2>
              <button
                onClick={onOpenBeneficiaryModal}
                className="text-xs text-[#0f3d7d] hover:underline font-semibold"
              >
                + Ajouter
              </button>
            </div>

            {/* Search */}
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={beneficiarySearch}
                onChange={(e) => setBeneficiarySearch(e.target.value)}
                placeholder="Rechercher un bénéficiaire..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-700"
              />
            </div>

            {/* List */}
            <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto pr-1">
              {filteredBeneficiaries.map((ben) => (
                <div
                  key={ben.id}
                  onClick={() => setSelectedBenId(ben.id)}
                  className={`py-2.5 px-2 rounded-xl flex items-center justify-between cursor-pointer transition-colors ${
                    selectedBenId === ben.id ? 'bg-blue-50/70 border border-blue-200' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
                      {ben.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800 leading-tight">
                        {ben.name}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {ben.bankName} • {ben.iban.slice(-8)}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                    {ben.category}
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={onOpenBeneficiaryModal}
              className="w-full mt-4 py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5 text-blue-700" />
              <span>Ajouter un nouveau compte tiers</span>
            </button>
          </div>

          {/* Scheduled transfers */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80">
            <h3 className="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-700" />
              Virements permanents actifs
            </h3>
            <div className="space-y-2 text-xs text-slate-600">
              <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-150">
                <div>
                  <p className="font-semibold text-slate-800">Loyer SCI Immo Paris</p>
                  <p className="text-[11px] text-slate-400">Le 1er de chaque mois</p>
                </div>
                <span className="font-bold text-slate-900">- 750,00 €</span>
              </div>
              <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-150">
                <div>
                  <p className="font-semibold text-slate-800">Versement Livret A</p>
                  <p className="text-[11px] text-slate-400">Le 28 de chaque mois</p>
                </div>
                <span className="font-bold text-emerald-600">+ 100,00 €</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
