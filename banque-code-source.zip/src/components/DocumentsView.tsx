import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Search, 
  Filter, 
  Eye, 
  Calendar, 
  ShieldCheck, 
  FileCheck,
  CheckCircle2
} from 'lucide-react';
import { BankAccount, BankDocument } from '../types';

interface DocumentsViewProps {
  documents: BankDocument[];
  accounts: BankAccount[];
  onOpenRib: (account?: BankAccount) => void;
  accountHolder?: string;
}

export const DocumentsView: React.FC<DocumentsViewProps> = ({
  documents,
  accounts,
  onOpenRib,
  accountHolder = 'Titulaire du compte',
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [previewDoc, setPreviewDoc] = useState<BankDocument | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const filteredDocs = documents.filter((doc) => {
    const matchesCategory = activeCategory === 'all' || doc.category === activeCategory;
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleDownload = (doc: BankDocument) => {
    setDownloadSuccess(`Téléchargement de "${doc.title}" en cours...`);
    setTimeout(() => {
      setDownloadSuccess(null);
    }, 2500);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Documents & Relevés
          </h1>
          <p className="text-sm text-slate-500">
            Consultez, téléchargez et imprimez vos e-relevés de compte, attestations et contrats signés.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={() => onOpenRib(accounts[0])}
            className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all flex items-center gap-2"
          >
            <FileCheck className="w-4 h-4" />
            <span>Générer un RIB officiel</span>
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {downloadSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto text-xs">
          {[
            { id: 'all', label: 'Tous les documents' },
            { id: 'statement', label: 'Relevés bancaires' },
            { id: 'rib', label: 'RIB & Attestations' },
            { id: 'tax', label: 'Fiscalité' },
            { id: 'contract', label: 'Contrats' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-full font-medium transition-colors shrink-0 ${
                activeCategory === cat.id
                  ? 'bg-blue-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par titre..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-700"
          />
        </div>
      </div>

      {/* Document List */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="grid grid-cols-12 gap-4 px-6 py-3 border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
          <div className="col-span-6 sm:col-span-6">Titre du document</div>
          <div className="col-span-3 sm:col-span-3">Compte rattaché</div>
          <div className="col-span-3 sm:col-span-3 text-right">Actions</div>
        </div>

        <div className="divide-y divide-slate-100">
          {filteredDocs.map((doc) => (
            <div
              key={doc.id}
              className="grid grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-slate-50 transition-colors text-xs"
            >
              {/* Title & Icon */}
              <div className="col-span-6 sm:col-span-6 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center shrink-0">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 hover:text-blue-800 transition-colors">
                    {doc.title}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {doc.date} • Format PDF ({doc.size})
                  </p>
                </div>
              </div>

              {/* Account reference */}
              <div className="col-span-3 sm:col-span-3 text-slate-600">
                <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-medium">
                  {doc.accountName}
                </span>
              </div>

              {/* Action buttons */}
              <div className="col-span-3 sm:col-span-3 flex items-center justify-end gap-2">
                <button
                  onClick={() => setPreviewDoc(doc)}
                  className="p-2 text-slate-500 hover:text-blue-800 hover:bg-slate-100 rounded-lg transition-colors"
                  title="Aperçu rapide"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDownload(doc)}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 font-semibold rounded-lg text-xs flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Télécharger</span>
                </button>
              </div>
            </div>
          ))}

          {filteredDocs.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs">
              Aucun document ne correspond à vos filtres.
            </div>
          )}
        </div>
      </div>

      {/* Document Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-blue-800" />
                <h3 className="font-bold text-slate-900 text-sm">
                  {previewDoc.title}
                </h3>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            {/* Realistic Document Preview Box */}
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 font-serif text-slate-800 text-xs space-y-4">
              <div className="flex justify-between items-center border-b border-slate-300 pb-3">
                <div>
                  <span className="font-sans font-bold text-base tracking-tight text-blue-950">RELEVÉ DE COMPTE OFFICIEL</span>
                  <p className="text-[10px] text-slate-500 font-sans">Direction des opérations bancaires</p>
                </div>
                <div className="text-right text-[10px] font-sans text-slate-500">
                  <p>Date : {previewDoc.date}</p>
                  <p>Réf : DOC-{previewDoc.id.toUpperCase()}</p>
                </div>
              </div>

              <div>
                <p className="font-bold">Titulaire du compte :</p>
                <p>{accountHolder}</p>
                <p>12 Rue de la République, 75011 Paris</p>
              </div>

              <div className="py-4 text-center border-y border-dashed border-slate-300">
                <p className="font-bold text-sm text-slate-900">{previewDoc.title}</p>
                <p className="text-[11px] text-slate-500 font-sans mt-1">
                  Document certifié conforme avec signature électronique CertTrust
                </p>
              </div>

              <div className="flex justify-between text-[11px] text-slate-500 font-sans pt-2">
                <span>IBAN : FR76 3000 4012 3456 7890 1234 207</span>
                <span>Code Banque : 30004</span>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50"
              >
                Fermer
              </button>
              <button
                onClick={() => {
                  handleDownload(previewDoc);
                  setPreviewDoc(null);
                }}
                className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Télécharger le PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
