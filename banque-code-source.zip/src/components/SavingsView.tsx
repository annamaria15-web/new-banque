import React, { useState } from 'react';
import { 
  PiggyBank, 
  TrendingUp, 
  ShieldCheck, 
  Calculator, 
  ArrowRight, 
  Coins, 
  FileText, 
  Building2, 
  Percent, 
  Info
} from 'lucide-react';
import { BankAccount } from '../types';

interface SavingsViewProps {
  accounts: BankAccount[];
  onOpenTransfer: (fromAccountId?: string) => void;
}

export const SavingsView: React.FC<SavingsViewProps> = ({
  accounts,
  onOpenTransfer,
}) => {
  const savings = accounts.filter(a => a.type === 'savings' || a.type === 'pel');
  const totalSavings = savings.reduce((acc, curr) => acc + curr.balance, 0);

  // Simulator states
  const [simInitial, setSimInitial] = useState(2500);
  const [simMonthly, setSimMonthly] = useState(150);
  const [simYears, setSimYears] = useState(5);
  const [simRate, setSimRate] = useState(3.00);

  // Simple compound interest calculation:
  // FV = P*(1+r/12)^(12*t) + PMT * [((1+r/12)^(12*t) - 1)/(r/12)]
  const calculateProjection = () => {
    const r = simRate / 100 / 12;
    const n = simYears * 12;
    const futureInitial = simInitial * Math.pow(1 + r, n);
    const futureMonthly = simMonthly * ((Math.pow(1 + r, n) - 1) / r);
    const total = futureInitial + futureMonthly;
    const totalDeposited = simInitial + simMonthly * n;
    const interestEarned = total - totalDeposited;

    return {
      total: Math.round(total),
      deposited: Math.round(totalDeposited),
      interest: Math.round(interestEarned),
    };
  };

  const projection = calculateProjection();

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Épargne & Placements
          </h1>
          <p className="text-sm text-slate-500">
            Faites fructifier vos liquidités en toute sécurité avec nos livrets réglementés et plans d'épargne.
          </p>
        </div>

        <button
          onClick={() => onOpenTransfer()}
          className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
        >
          Alimenter un livret
        </button>
      </div>

      {/* Hero Overview Banner */}
      <div className="bg-gradient-to-r from-[#0d2d5d] to-[#0a2347] rounded-2xl p-6 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-blue-200">
            Total de votre épargne
          </span>
          <div className="text-3xl sm:text-4xl font-black mt-1">
            + {totalSavings.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
          </div>
          <p className="text-xs text-blue-200/80 mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Fonds garantis par l'État jusqu'à 100 000 € (FGDR).
          </p>
        </div>

        <div className="flex gap-3">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center min-w-[110px]">
            <p className="text-[11px] text-blue-200">Livrets actifs</p>
            <p className="text-lg font-bold">{savings.length}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center min-w-[110px]">
            <p className="text-[11px] text-blue-200">Taux moyen</p>
            <p className="text-lg font-bold">2,17%</p>
          </div>
        </div>
      </div>

      {/* Savings Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {savings.map((acc) => (
          <div 
            key={acc.id}
            className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800">
                  Taux garanti : {acc.rate?.toFixed(2)}%
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  {acc.maskedIban}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900">{acc.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{acc.subtitle}</p>

              <div className="my-5">
                <p className="text-xs text-slate-400">Solde disponible</p>
                <p className="text-2xl font-extrabold text-slate-900 mt-0.5">
                  {acc.balance.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => onOpenTransfer(acc.id)}
                className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center gap-1"
              >
                <span>Faire un versement</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Interest Simulator & Future Projection */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm">
        <div className="flex items-center gap-2 mb-6">
          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Simulateur d'intérêts et de capital
            </h2>
            <p className="text-xs text-slate-500">
              Estimez l'évolution de votre épargne dans le temps avec versements programmés.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sliders (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            {/* Initial amount */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-2">
                <span>Dépôt initial</span>
                <span className="font-bold text-blue-900">{simInitial.toLocaleString()} €</span>
              </div>
              <input
                type="range"
                min="100"
                max="30000"
                step="100"
                value={simInitial}
                onChange={(e) => setSimInitial(Number(e.target.value))}
                className="w-full accent-blue-800"
              />
            </div>

            {/* Monthly deposit */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-2">
                <span>Versement mensuel programmé</span>
                <span className="font-bold text-blue-900">{simMonthly} € / mois</span>
              </div>
              <input
                type="range"
                min="0"
                max="1000"
                step="25"
                value={simMonthly}
                onChange={(e) => setSimMonthly(Number(e.target.value))}
                className="w-full accent-blue-800"
              />
            </div>

            {/* Duration */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-2">
                <span>Durée du placement</span>
                <span className="font-bold text-blue-900">{simYears} an{simYears > 1 ? 's' : ''}</span>
              </div>
              <input
                type="range"
                min="1"
                max="15"
                step="1"
                value={simYears}
                onChange={(e) => setSimYears(Number(e.target.value))}
                className="w-full accent-blue-800"
              />
            </div>

            {/* Rate select */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Support de placement
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setSimRate(3.0)}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    simRate === 3.0 ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  Livret A (3,00%)
                </button>
                <button
                  type="button"
                  onClick={() => setSimRate(2.5)}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    simRate === 2.5 ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  Compte Épargne (2,50%)
                </button>
                <button
                  type="button"
                  onClick={() => setSimRate(1.0)}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    simRate === 1.0 ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  PEL (1,00%)
                </button>
              </div>
            </div>
          </div>

          {/* Results Box (5 cols) */}
          <div className="lg:col-span-5 bg-slate-50 rounded-2xl p-6 border border-slate-200/80 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Capital estimé au bout de {simYears} ans
              </span>
              <div className="text-3xl font-black text-slate-900 mt-1">
                {projection.total.toLocaleString()} €
              </div>

              <div className="mt-6 space-y-3 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500">Total de vos versements :</span>
                  <span className="font-semibold text-slate-800">{projection.deposited.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500">Intérêts nets cumulés :</span>
                  <span className="font-bold text-emerald-600">+ {projection.interest.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-500">Rémunération annuelle :</span>
                  <span className="font-semibold text-slate-800">{simRate}% net d'impôt</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onOpenTransfer()}
              className="w-full mt-6 py-2.5 px-4 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl transition-all shadow-sm"
            >
              Mettre en place un versement automatique
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
