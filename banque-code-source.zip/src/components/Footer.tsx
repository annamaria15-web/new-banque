import React from 'react';
import { ShieldCheck, Code } from 'lucide-react';

interface FooterProps {
  onOpenHelp: () => void;
  onOpenLegal: (title: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenHelp, onOpenLegal }) => {
  const [isDownloading, setIsDownloading] = React.useState(false);

  const handleDownloadCode = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDownloading(true);
    try {
      const link = document.createElement('a');
      link.href = '/api/download-zip';
      link.download = 'banque-code-source.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      window.location.href = '/banque-code-source.zip';
    } finally {
      setTimeout(() => setIsDownloading(false), 2500);
    }
  };

  return (
    <footer className="border-t border-slate-200/80 bg-white py-6 px-4 sm:px-8 mt-auto">
      <div className="max-w-[1600px] mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          {/* Left Brand */}
          <div className="flex items-center gap-3">
            <div className="flex items-center select-none">
              <img 
                src="/logo.jpeg" 
                alt="Logo" 
                className="h-6 sm:h-7 w-auto max-w-[110px] sm:max-w-[125px] object-contain opacity-90"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (target.src.endsWith('/logo.jpeg')) {
                    target.src = '/logo.jpg';
                  } else if (target.src.endsWith('/logo.jpg')) {
                    target.src = '/logo.png';
                  } else if (target.src.endsWith('/logo.png')) {
                    target.src = '/logo.svg';
                  }
                }}
              />
            </div>
            <span className="hidden sm:inline text-slate-300">|</span>
            <span className="text-slate-500 hidden sm:inline">
              Établissement de crédit français agréé par l'ACPR et la Banque de France
            </span>
          </div>

          {/* Right Links */}
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
            <button 
              onClick={() => onOpenLegal('Mentions légales')} 
              className="hover:text-blue-900 transition-colors"
            >
              Mentions légales & RCS
            </button>
            <button 
              onClick={() => onOpenLegal('Sécurité & DSP2')} 
              className="hover:text-blue-900 transition-colors"
            >
              Sécurité & DSP2
            </button>
            <button 
              onClick={() => onOpenLegal('Garantie des dépôts FGDR')} 
              className="hover:text-blue-900 transition-colors"
            >
              Garantie FGDR
            </button>
            <button 
              onClick={() => onOpenLegal('Tarifs bancaires')} 
              className="hover:text-blue-900 transition-colors"
            >
              Tarifs & Frais
            </button>
            <button 
              onClick={onOpenHelp} 
              className="hover:text-blue-900 transition-colors font-semibold text-[#0f3d7d]"
            >
              Opposition & Assistance
            </button>
            <a
              href="/api/download-zip"
              download="banque-code-source.zip"
              onClick={handleDownloadCode}
              className="hover:text-blue-900 transition-colors flex items-center gap-1 font-medium text-slate-600 hover:text-[#0f3d7d] cursor-pointer"
              title="Télécharger directement le code source du projet (fichier ZIP)"
            >
              <Code className="w-3.5 h-3.5 text-slate-400" />
              <span>{isDownloading ? 'Téléchargement...' : 'Code'}</span>
            </a>
          </div>
        </div>

        {/* Regulatory fine-print line */}
        <div className="pt-3 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-2 text-[10px] text-slate-400">
          <p>
            Société Anonyme bancaire au capital de 1 200 000 000 € • Siège social : 14 Boulevard des Italiens, 75009 Paris • RCS Paris B 498 120 481 • Code Banque 30004.
          </p>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-slate-500 font-medium">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              Adhérent FGDR (100 000 €)
            </span>
            <span>•</span>
            <span>Médiateur de la FBF</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
