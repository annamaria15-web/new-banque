import React, { useState } from 'react';
import { 
  UserCheck, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  Calendar, 
  CheckCircle2, 
  MessageSquare, 
  FileQuestion,
  Sparkles
} from 'lucide-react';
import { AdvisorInfo } from '../types';

interface AdvisorViewProps {
  advisor: AdvisorInfo;
  onOpenAppointment: () => void;
  accountHolder?: string;
}

export const AdvisorView: React.FC<AdvisorViewProps> = ({
  advisor,
  onOpenAppointment,
  accountHolder = 'Client',
}) => {
  const firstName = accountHolder.split(' ')[0] || accountHolder;

  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'advisor',
      text: `Bonjour ${firstName}, je reste à votre entière disposition pour tout projet ou question sur vos plafonds et comptes.`,
      time: '18 sept. 10:14',
    },
    {
      id: 2,
      sender: 'user',
      text: `Bonjour ${advisor.name}, merci beaucoup pour le suivi !`,
      time: '18 sept. 11:02',
    }
  ]);
  const [inputText, setInputText] = useState('');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: inputText,
      time: 'À l’instant',
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');

    // Simulate friendly advisor response
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          id: Date.now() + 1,
          sender: 'advisor',
          text: `Message bien reçu ${firstName}. Je consulte votre dossier et reviens vers vous dès que possible !`,
          time: 'À l’instant',
        }
      ]);
    }, 1200);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Mon Conseiller Dédié
          </h1>
          <p className="text-sm text-slate-500">
            Échangez directement avec votre conseillère attitrée et prenez rendez-vous en agence ou à distance.
          </p>
        </div>

        <button
          onClick={onOpenAppointment}
          className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
        >
          Prendre un rendez-vous
        </button>
      </div>

      {/* Main Grid: Profile & Agency (Left 5) + Chat Thread (Right 7) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Advisor Card & Agency Details */}
        <div className="lg:col-span-5 space-y-5">
          {/* Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm text-center sm:text-left">
            <div className="flex flex-col sm:flex-row items-center gap-4 mb-5">
              <img
                src={advisor.avatarUrl}
                alt={advisor.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 rounded-full object-cover ring-4 ring-blue-100 shadow-md"
              />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-800 bg-blue-50 px-2 py-0.5 rounded-full">
                  Conseillère Attitrée
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-1">
                  {advisor.name}
                </h2>
                <p className="text-xs text-slate-500">
                  {advisor.title}
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs border-t border-slate-100 pt-4">
              <div className="flex items-center gap-3 text-slate-700">
                <Phone className="w-4 h-4 text-blue-700 shrink-0" />
                <a href={`tel:${advisor.phone.replace(/\s+/g, '')}`} className="hover:underline font-medium">
                  {advisor.phone}
                </a>
              </div>

              <div className="flex items-center gap-3 text-slate-700">
                <Mail className="w-4 h-4 text-blue-700 shrink-0" />
                <a href={`mailto:${advisor.email}`} className="hover:underline truncate font-medium">
                  {advisor.email}
                </a>
              </div>

              <div className="flex items-start gap-3 text-slate-700">
                <MapPin className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">{advisor.agency}</p>
                  <p className="text-slate-500">{advisor.agencyAddress}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 text-slate-700">
                <Clock className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Horaires d'ouverture</p>
                  <p className="text-slate-500">{advisor.availableHours}</p>
                </div>
              </div>
            </div>

            <button
              onClick={onOpenAppointment}
              className="w-full mt-5 py-2.5 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Réserver un créneau (Visio ou Agence)</span>
            </button>
          </div>

          {/* Tips Box */}
          <div className="bg-blue-50/70 border border-blue-150 rounded-2xl p-5 text-xs text-slate-700">
            <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-700" />
              Le saviez-vous ?
            </h4>
            <p className="text-slate-600 leading-relaxed">
              Vous pouvez nous transmettre vos justificatifs de revenus ou fiches de paie directement par message sécurisé pour accélérer vos demandes de crédit.
            </p>
          </div>
        </div>

        {/* Right Column: Secure Messaging Interface */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200/80 shadow-sm flex flex-col h-[520px]">
          {/* Chat Header */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img
                  src={advisor.avatarUrl}
                  alt={advisor.name}
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover ring-2 ring-slate-100"
                />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white absolute bottom-0 right-0" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900">{advisor.name}</h3>
                <p className="text-[11px] text-emerald-600 font-medium">Disponible en agence</p>
              </div>
            </div>
            <span className="text-[11px] text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
              Canal bancaire chiffré
            </span>
          </div>

          {/* Messages Flow */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/40">
            {messages.map((m) => {
              const isUser = m.sender === 'user';
              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs shadow-sm leading-relaxed ${
                      isUser
                        ? 'bg-[#0f3d7d] text-white rounded-br-xs'
                        : 'bg-white text-slate-800 border border-slate-200/70 rounded-bl-xs'
                    }`}
                  >
                    {m.text}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 px-1">
                    {m.time}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-100 bg-white flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Écrivez un message sécurisé à ${advisor.name}...`}
              className="flex-1 px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 text-slate-800"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 bg-[#0f3d7d] hover:bg-[#0c2f61] disabled:bg-slate-300 text-white rounded-xl transition-colors shadow-sm"
              title="Envoyer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
