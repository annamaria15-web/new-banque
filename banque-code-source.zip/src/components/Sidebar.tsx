import React from 'react';
import { 
  LayoutDashboard, 
  CreditCard, 
  ArrowLeftRight, 
  PiggyBank, 
  Percent, 
  UserCheck, 
  FileText, 
  Settings, 
  ChevronRight,
  Headphones,
  ShieldAlert,
  ShieldCheck,
  LogOut
} from 'lucide-react';
import { NavigationTab } from '../types';

interface SidebarProps {
  currentTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  onOpenHelp: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onNavigate,
  onOpenHelp,
  onLogout,
}) => {
  const menuItems = [
    {
      id: 'dashboard' as NavigationTab,
      label: 'Tableau de bord',
      icon: LayoutDashboard,
      hasArrow: false,
    },
    {
      id: 'accounts' as NavigationTab,
      label: 'Comptes & Cartes CB',
      icon: CreditCard,
      hasArrow: true,
    },
    {
      id: 'transfers' as NavigationTab,
      label: 'Virements SEPA',
      icon: ArrowLeftRight,
      hasArrow: true,
    },
    {
      id: 'savings' as NavigationTab,
      label: 'Épargne & Livrets',
      icon: PiggyBank,
      hasArrow: true,
    },
    {
      id: 'loans' as NavigationTab,
      label: 'Crédits & Prêts',
      icon: Percent,
      hasArrow: true,
    },
    {
      id: 'advisor' as NavigationTab,
      label: 'Mon Conseiller',
      icon: UserCheck,
      hasArrow: true,
    },
    {
      id: 'documents' as NavigationTab,
      label: 'Relevés & Documents',
      icon: FileText,
      hasArrow: true,
    },
    {
      id: 'settings' as NavigationTab,
      label: 'Paramètres & Sécurité',
      icon: Settings,
      hasArrow: true,
    },
  ];

  return (
    <aside className="w-64 lg:w-72 shrink-0 hidden md:flex flex-col justify-between py-6 pr-4">
      {/* Navigation Links */}
      <nav className="space-y-1.5">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-[#0f3d7d] text-white shadow-md shadow-blue-950/15'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/90'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span className="tracking-tight text-[13.5px]">{item.label}</span>
              </div>
              {item.hasArrow && !isActive && (
                <ChevronRight className="w-4 h-4 text-slate-400" />
              )}
            </button>
          );
        })}

        {/* Secure Logout Option */}
        <div className="pt-2 border-t border-slate-200/80 mt-2">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl font-medium transition-all text-xs text-red-600 hover:bg-red-50/80 group active:scale-[0.98]"
            title="Se déconnecter de votre espace client sécurisé"
          >
            <div className="flex items-center gap-3.5">
              <LogOut className="w-4 h-4 text-red-500 group-hover:scale-105 transition-transform" />
              <span className="tracking-tight text-[13px] font-semibold">Déconnexion</span>
            </div>
            <span className="text-[10px] text-red-400 bg-red-100/60 px-1.5 py-0.5 rounded font-mono">DSP2</span>
          </button>
        </div>
      </nav>

      {/* French Banking Trust & Assistance Box */}
      <div className="mt-8 space-y-3">
        {/* Urgent Opposition Card */}
        <div 
          onClick={onOpenHelp}
          className="bg-rose-50/70 border border-rose-200/80 rounded-xl p-3 text-xs cursor-pointer hover:bg-rose-100/80 transition-colors"
        >
          <div className="flex items-center gap-2 text-rose-800 font-bold mb-1">
            <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
            <span>Opposition CB (24h/24)</span>
          </div>
          <p className="text-[11px] text-rose-700 font-semibold">
            0 800 04 04 04 <span className="font-normal text-rose-600 text-[10px]">(Numéro vert France)</span>
          </p>
        </div>

        {/* Need Help Card */}
        <div className="bg-blue-50/70 border border-blue-100/80 rounded-2xl p-4 text-center shadow-sm">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center mx-auto mb-2 shadow-sm border border-blue-150">
            <Headphones className="w-4 h-4 text-[#0f3d7d]" />
          </div>
          <h4 className="text-xs font-bold text-slate-900 mb-0.5">
            Service Clientèle Particuliers
          </h4>
          <p className="text-[11px] text-slate-600 mb-3 leading-relaxed">
            Agence Paris Opéra à vos côtés du mar. au sam.
          </p>
          <button
            onClick={onOpenHelp}
            className="w-full py-2 px-3 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all active:scale-[0.98]"
          >
            Nous contacter
          </button>

          <div className="mt-2.5 pt-2 border-t border-blue-200/50 flex items-center justify-center gap-1.5 text-[10px] text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Fonds garantis FGDR (100 k€)</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
