import React, { useState } from 'react';
import { Search, Bell, MessageSquare, ChevronDown, User as UserIcon, Shield, LogOut, CheckCircle2, Lock, ShieldCheck } from 'lucide-react';
import { NavigationTab } from '../types';

interface NavbarProps {
  currentTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  onOpenSearchModal?: (query: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isAuthenticated: boolean;
  onLogout: () => void;
  onLoginClick?: () => void;
  accountHolder?: string;
  clientId?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  searchQuery,
  setSearchQuery,
  isAuthenticated,
  onLogout,
  onLoginClick,
  accountHolder = 'Titulaire du compte',
  clientId = '84920194',
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const initials = accountHolder
    .split(' ')
    .filter(Boolean)
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) || 'TC';
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'Virement de salaire reçu (SEPA)',
      detail: '+ 2 850,00 € crédités par TechCorp France SAS.',
      time: 'Il y a 2 jours',
      unread: true,
    },
    {
      id: 2,
      title: 'Pass Sécurité DSP2 validé',
      detail: 'Paiement sécurisé par carte CB de 56,32 € confirmé sur votre mobile.',
      time: 'Il y a 4 jours',
      unread: true,
    },
    {
      id: 3,
      title: 'e-Relevé mensuel disponible',
      detail: 'Votre relevé de compte certifié du mois d’août 2025 est téléchargeable.',
      time: 'Il y a 1 semaine',
      unread: true,
    },
  ]);

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  };

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-[0_1px_3px_rgba(0,0,0,0.03)]">
      {/* Top micro-bar: French Regulatory & Trust Banner */}
      <div className="bg-[#08172c] text-slate-300 text-[10px] px-4 sm:px-8 py-1 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          {/* French Flag miniature */}
          <div className="flex w-3.5 h-2.5 rounded-xs overflow-hidden shadow-xs shrink-0">
            <div className="w-1/3 bg-[#002395]" />
            <div className="w-1/3 bg-white" />
            <div className="w-1/3 bg-[#ED2939]" />
          </div>
          <span className="font-medium text-slate-200">
            Banque française agréée ACPR (Banque de France) n° 30004
          </span>
          <span className="hidden md:inline text-slate-500">•</span>
          <span className="hidden md:inline text-slate-400">
            Garantie des Dépôts FGDR jusqu'à 100 000 €
          </span>
        </div>

        <div className="flex items-center gap-3 text-slate-300">
          <span className="flex items-center gap-1 text-emerald-400 font-medium">
            <Lock className="w-2.5 h-2.5" />
            Espace Sécurisé DSP2 / SSL 256 bits
          </span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-400">Paris (UTC+2)</span>
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
        {/* ========================================================= */}
        {/* LOGO DU SITE : L'image prend TOUTE la place               */}
        {/* Pas de texte d'accompagnement - logo pur et visible       */}
        {/* ========================================================= */}
        <div 
          onClick={() => onNavigate('dashboard')}
          className="flex items-center cursor-pointer select-none group shrink-0"
          title="Retour au tableau de bord"
        >
          {/* Image du logo compact et équilibré */}
          <img 
            src="/logo.jpeg" 
            alt="Logo" 
            className="h-8 sm:h-9 max-h-9 w-auto max-w-[125px] sm:max-w-[145px] object-contain transition-transform duration-200 group-hover:scale-[1.02]"
            onError={(e) => {
              const target = e.currentTarget;
              if (target.src.endsWith('/logo.jpeg')) {
                target.src = '/logo.jpg';
              } else if (target.src.endsWith('/logo.jpg')) {
                target.src = '/logo.png';
              } else if (target.src.endsWith('/logo.png')) {
                target.src = '/logo.svg';
              }
            }}
          />
        </div>

        {/* Central Search Bar or Trust Badge */}
        {!isAuthenticated ? (
          <div className="hidden md:flex items-center gap-2 text-xs text-slate-500">
            <span className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/90 px-3 py-1.5 rounded-full font-medium text-slate-600">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Portail sécurisé d'authentification bancaire
            </span>
          </div>
        ) : (
          <div className="flex-1 max-w-2xl hidden md:block">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher une opération, un virement SEPA, un RIB ou un relevé..."
                className="w-full pl-10 pr-4 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-sm text-slate-800 placeholder-slate-400 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-800/20 focus:border-blue-700 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 px-1 py-0.5"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        )}

        {/* Right Tools & User Info */}
        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          {!isAuthenticated ? (
            <div className="flex items-center gap-3">
              <span className="hidden sm:inline text-xs text-slate-500">
                Assistance : <strong className="text-slate-800 font-semibold">0 800 04 04 04</strong>
              </span>
              <button
                onClick={onLoginClick}
                className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-2 transition-all active:scale-95"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Espace Connexion</span>
              </button>
            </div>
          ) : (
            <>
              {/* Notifications button */}
              <div className="relative">
                <button
                  onClick={() => {
                    setShowNotifications(!showNotifications);
                    setShowUserMenu(false);
                  }}
                  className="relative p-2 rounded-full text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors focus:outline-none"
                  title="Notifications bancaires"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 bg-red-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-150 py-2 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between">
                      <h4 className="font-semibold text-slate-900 text-sm">Notifications bancaires</h4>
                      {unreadCount > 0 && (
                        <button
                          onClick={markAllRead}
                          className="text-xs text-blue-700 hover:text-blue-900 font-medium"
                        >
                          Tout marquer comme lu
                        </button>
                      )}
                    </div>
                    <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                      {notifications.map((n) => (
                        <div
                          key={n.id}
                          className={`p-3.5 hover:bg-slate-50 transition-colors flex gap-3 ${n.unread ? 'bg-blue-50/40' : ''}`}
                        >
                          {n.unread ? (
                            <div className="w-2 h-2 rounded-full bg-blue-600 mt-1.5 shrink-0" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                          )}
                          <div className="flex-1 text-xs">
                            <p className="font-semibold text-slate-800">{n.title}</p>
                            <p className="text-slate-500 mt-0.5">{n.detail}</p>
                            <p className="text-[10px] text-slate-400 mt-1">{n.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Messages link */}
              <button
                onClick={() => onNavigate('advisor')}
                className="p-2 rounded-full text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors focus:outline-none"
                title="Messagerie sécurisée avec votre conseiller"
              >
                <MessageSquare className="w-5 h-5" />
              </button>

              {/* User Profile Pill */}
              <div className="relative">
                <button
                  onClick={() => {
                    setShowUserMenu(!showUserMenu);
                    setShowNotifications(false);
                  }}
                  className="flex items-center gap-2.5 pl-1.5 pr-2 py-1 rounded-full hover:bg-slate-100 transition-colors text-left focus:outline-none"
                >
                  <div className="w-9 h-9 rounded-full bg-[#0b1c34] text-white flex items-center justify-center font-bold text-xs tracking-wider ring-2 ring-slate-100 shadow-sm">
                    {initials}
                  </div>
                  <div className="hidden sm:block">
                    <p className="text-xs font-bold text-slate-900 leading-tight">
                      {accountHolder}
                    </p>
                    <p className="text-[11px] text-slate-500 font-normal">
                      Compte Particulier France
                    </p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-500" />
                </button>

                {/* Profile Dropdown */}
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-150 py-1.5 z-50 animate-in fade-in">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900">{accountHolder}</p>
                      <p className="text-[11px] text-slate-500 font-mono">N° Client : {clientId}</p>
                      <p className="text-[10px] text-emerald-600 font-medium mt-0.5 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Espace Particulier certifié
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        onNavigate('settings');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                    >
                      <UserIcon className="w-4 h-4 text-slate-500" /> Mon Profil & Coordonnées
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('settings');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                    >
                      <Shield className="w-4 h-4 text-slate-500" /> Pass Sécurité & DSP2
                    </button>

                    <div className="border-t border-slate-100 my-1" />
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onLogout();
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-50 flex items-center gap-2.5 font-medium"
                    >
                      <LogOut className="w-4 h-4 text-red-500" /> Déconnexion sécurisée
                    </button>
                  </div>
                )}
              </div>

              {/* Quick 1-click Logout Icon Button */}
              <button
                onClick={onLogout}
                className="p-2 rounded-full text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors focus:outline-none hidden sm:flex items-center justify-center"
                title="Déconnexion sécurisée de votre espace"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
