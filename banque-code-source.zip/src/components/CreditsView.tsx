import React, { useState } from 'react';
import { 
  Building2, 
  Car, 
  Calendar, 
  Percent, 
  ArrowRight, 
  Clock, 
  CheckCircle2, 
  Calculator, 
  Info,
  ShieldCheck
} from 'lucide-react';
import { Loan } from '../types';

interface CreditsViewProps {
  loan: Loan;
  onOpenAppointment: () => void;
}

export const CreditsView: React.FC<CreditsViewProps> = ({
  loan,
  onOpenAppointment,
}) => {
  // Loan simulator state
  const [borrowAmount, setBorrowAmount] = useState(15000);
  const [durationMonths, setDurationMonths] = useState(36);
  const [loanType, setLoanType] = useState<'auto' | 'perso' | 'travaux'>('auto');

  const getRate = () => {
    switch (loanType) {
      case 'auto': return 2.90;
      case 'travaux': return 3.40;
      default: return 3.90;
    }
  };

  const annualRate = getRate();
  const monthlyRate = annualRate / 100 / 12;
  const monthlyPayment = (borrowAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -durationMonths));
  const totalCost = monthlyPayment * durationMonths;
  const totalInterest = totalCost - borrowAmount;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Mes Crédits & Financements
          </h1>
          <p className="text-sm text-slate-500">
            Suivez le remboursement de vos prêts en cours et simulez un nouveau projet de financement.
          </p>
        </div>

        <button
          onClick={onOpenAppointment}
          className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
        >
          Prendre RDV avec mon conseiller
        </button>
      </div>

      {/* Active Loan Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                En cours de remboursement
              </span>
              <h2 className="text-base font-bold text-slate-900 mt-1">
                {loan.title}
              </h2>
            </div>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Réf : {loan.contractNumber}
          </span>
        </div>

        {/* Progress & metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 py-6 border-b border-slate-100">
          <div>
            <span className="text-xs text-slate-400">Capital restant dû</span>
            <p className="text-2xl font-extrabold text-slate-900 mt-0.5">
              {loan.remainingAmount.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              sur {loan.initialAmount.toLocaleString()} € empruntés
            </p>
          </div>

          <div>
            <span className="text-xs text-slate-400">Mensualité actuelle</span>
            <p className="text-2xl font-extrabold text-[#0f3d7d] mt-0.5">
              {loan.monthlyPayment.toFixed(2)} €
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Assurance comprise ({loan.insuranceRate}%)
            </p>
          </div>

          <div>
            <span className="text-xs text-slate-400">Taux débiteur fixe</span>
            <p className="text-2xl font-extrabold text-slate-900 mt-0.5">
              {loan.interestRate.toFixed(2)}%
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              TAEG fixe : {loan.taeg.toFixed(2)}%
            </p>
          </div>

          <div>
            <span className="text-xs text-slate-400">Prochaine échéance</span>
            <p className="text-base font-bold text-slate-900 mt-1 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              {loan.nextPaymentDate}
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Reste {loan.remainingMonths} mois / {loan.durationMonths}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-5">
          <div className="flex justify-between text-xs text-slate-500 mb-1.5">
            <span>Remboursement effectué (29%)</span>
            <span>Fin du contrat : Novembre 2027</span>
          </div>
          <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-700 rounded-full" 
              style={{ width: `${((loan.initialAmount - loan.remainingAmount) / loan.initialAmount) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Simulator: Nouveau projet de crédit */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm">
        <div className="flex items-center gap-2 mb-6">
          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Simuler un nouveau crédit
            </h2>
            <p className="text-xs text-slate-500">
              Un crédit vous engage et doit être remboursé. Vérifiez vos capacités de remboursement.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 space-y-5">
            {/* Project type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Type de projet
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setLoanType('auto')}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    loanType === 'auto' ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  Véhicule Éco (2,90%)
                </button>
                <button
                  type="button"
                  onClick={() => setLoanType('travaux')}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    loanType === 'travaux' ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  Travaux (3,40%)
                </button>
                <button
                  type="button"
                  onClick={() => setLoanType('perso')}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    loanType === 'perso' ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  Personnel (3,90%)
                </button>
              </div>
            </div>

            {/* Borrow amount */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-2">
                <span>Montant emprunté</span>
                <span className="font-bold text-blue-900">{borrowAmount.toLocaleString()} €</span>
              </div>
              <input
                type="range"
                min="1000"
                max="50000"
                step="500"
                value={borrowAmount}
                onChange={(e) => setBorrowAmount(Number(e.target.value))}
                className="w-full accent-blue-800"
              />
            </div>

            {/* Duration */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-2">
                <span>Durée de remboursement</span>
                <span className="font-bold text-blue-900">{durationMonths} mois ({Math.round(durationMonths / 12 * 10) / 10} ans)</span>
              </div>
              <input
                type="range"
                min="12"
                max="84"
                step="6"
                value={durationMonths}
                onChange={(e) => setDurationMonths(Number(e.target.value))}
                className="w-full accent-blue-800"
              />
            </div>
          </div>

          {/* Results Summary Box */}
          <div className="lg:col-span-5 bg-slate-50 rounded-2xl p-6 border border-slate-200/80 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Mensualité estimée
              </span>
              <div className="text-3xl font-black text-slate-900 mt-1">
                {monthlyPayment.toFixed(2)} € <span className="text-sm font-medium text-slate-500">/ mois</span>
              </div>

              <div className="mt-6 space-y-3 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500">Montant emprunté :</span>
                  <span className="font-semibold text-slate-800">{borrowAmount.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500">Coût total des intérêts :</span>
                  <span className="font-semibold text-slate-800">{totalInterest.toFixed(2)} €</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500">Montant total dû :</span>
                  <span className="font-bold text-slate-900">{totalCost.toFixed(2)} €</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-500">TAEG fixe :</span>
                  <span className="font-semibold text-blue-800">{annualRate.toFixed(2)}%</span>
                </div>
              </div>
            </div>

            <button
              onClick={onOpenAppointment}
              className="w-full mt-6 py-2.5 px-4 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl transition-all shadow-sm"
            >
              Faire une demande de prêt en ligne
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
