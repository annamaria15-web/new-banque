import React, { useState } from 'react';
import { 
  User, 
  Shield, 
  Bell, 
  Smartphone, 
  KeyRound, 
  Fingerprint, 
  Check, 
  AlertCircle,
  LogOut,
  Lock
} from 'lucide-react';

interface SettingsViewProps {
  onLogout?: () => void;
  accountHolder?: string;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ 
  onLogout,
  accountHolder = 'Titulaire du compte',
}) => {
  const [phone, setPhone] = useState('06 12 34 56 78');
  const [address, setAddress] = useState('12 Rue de la République, 75011 Paris');
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);
  const [biometricsEnabled, setBiometricsEnabled] = useState(true);
  const [notifBalance, setNotifBalance] = useState(true);
  const [notifTransfer, setNotifTransfer] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const initials = accountHolder
    .split(' ')
    .filter(Boolean)
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) || 'TC';

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Paramètres du Compte
          </h1>
          <p className="text-sm text-slate-500">
            Gérez vos informations personnelles, vos réglages de sécurité et vos préférences de notification.
          </p>
        </div>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Vos modifications ont été enregistrées avec succès.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Personal info form (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
            <div className="w-12 h-12 rounded-full bg-[#0b1c34] text-white flex items-center justify-center font-bold text-sm tracking-wider">
              {initials}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">{accountHolder}</h2>
              <p className="text-xs text-slate-500">Compte Particulier • N° Client : 9482 1049</p>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Coordonnées personnelles
            </h3>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Numéro de téléphone mobile certifié
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 text-slate-800"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Utilisé pour la validation des ordres et la réception des codes SMS SecurPass.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Adresse postale fiscale
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 text-slate-800"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-5 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
            >
              Enregistrer les modifications
            </button>
          </form>
        </div>

        {/* Right Column: Security & Notifications (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Security Box */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-blue-800" />
              Sécurité & Authentification
            </h3>

            {/* 2FA Toggle */}
            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <Smartphone className="w-5 h-5 text-blue-700" />
                <div>
                  <p className="text-xs font-semibold text-slate-900">Pass Sécurité Mobile</p>
                  <p className="text-[11px] text-slate-400">Validation biométrique des paiements</p>
                </div>
              </div>
              <button
                onClick={() => setTwoFactorEnabled(!twoFactorEnabled)}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  twoFactorEnabled ? 'bg-blue-800' : 'bg-slate-300'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  twoFactorEnabled ? 'translate-x-5' : 'translate-x-0'
                }`} />
              </button>
            </div>

            {/* Biometrics */}
            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <Fingerprint className="w-5 h-5 text-blue-700" />
                <div>
                  <p className="text-xs font-semibold text-slate-900">Face ID / Touch ID</p>
                  <p className="text-[11px] text-slate-400">Connexion rapide sans code secret</p>
                </div>
              </div>
              <button
                onClick={() => setBiometricsEnabled(!biometricsEnabled)}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  biometricsEnabled ? 'bg-blue-800' : 'bg-slate-300'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  biometricsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <button
              onClick={() => alert("Un lien de réinitialisation sécurisé a été envoyé par SMS à votre numéro certifié.")}
              className="w-full py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Changer mon mot de passe</span>
            </button>
          </div>

          {/* Notifications Box */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Bell className="w-4 h-4 text-blue-800" />
              Alertes & Notifications
            </h3>

            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <div>
                <p className="text-xs font-semibold text-slate-900">Alerte solde minimum</p>
                <p className="text-[11px] text-slate-400">Notification si solde &lt; 200 €</p>
              </div>
              <button
                onClick={() => setNotifBalance(!notifBalance)}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  notifBalance ? 'bg-blue-800' : 'bg-slate-300'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  notifBalance ? 'translate-x-5' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-xs font-semibold text-slate-900">Virements entrants</p>
                <p className="text-[11px] text-slate-400">Notification en temps réel</p>
              </div>
              <button
                onClick={() => setNotifTransfer(!notifTransfer)}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  notifTransfer ? 'bg-blue-800' : 'bg-slate-300'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  notifTransfer ? 'translate-x-5' : 'translate-x-0'
                }`} />
              </button>
            </div>
          </div>

          {/* Session & Logout Box */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-slate-700" />
              Session & Sécurité active
            </h3>
            <div className="text-xs text-slate-600 space-y-1">
              <p>Session active depuis : <strong>Paris (France)</strong></p>
              <p className="text-[11px] text-slate-400">Protocole de chiffrement TLS 1.3 / AES-256 GCM</p>
            </div>
            {onLogout && (
              <button
                type="button"
                onClick={onLogout}
                className="w-full py-2.5 px-4 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/80 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors active:scale-[0.99]"
              >
                <LogOut className="w-4 h-4 text-rose-600" />
                <span>Fermer la session (Déconnexion sécurisée)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
