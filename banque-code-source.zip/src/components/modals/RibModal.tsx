import React, { useState } from 'react';
import { FileText, Copy, Check, Printer, Download, ShieldCheck, X } from 'lucide-react';
import { BankAccount } from '../../types';

interface RibModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: BankAccount;
  accountHolder?: string;
}

export const RibModal: React.FC<RibModalProps> = ({ 
  isOpen, 
  onClose, 
  account,
  accountHolder = 'Titulaire du compte',
}) => {
  const [copiedIban, setCopiedIban] = useState(false);
  const [copiedBic, setCopiedBic] = useState(false);

  if (!isOpen) return null;

  const handleCopyIban = () => {
    navigator.clipboard.writeText(account.iban);
    setCopiedIban(true);
    setTimeout(() => setCopiedIban(false), 2000);
  };

  const handleCopyBic = () => {
    navigator.clipboard.writeText(account.bic);
    setCopiedBic(true);
    setTimeout(() => setCopiedBic(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Relevé d'Identité Bancaire (RIB)
              </h3>
              <p className="text-[11px] text-slate-500">{account.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Realistic Official French Document Box */}
        <div className="border border-slate-300 rounded-xl p-6 bg-slate-50/50 space-y-4 font-sans text-xs">
          {/* Header doc */}
          <div className="flex items-start justify-between border-b border-slate-200 pb-3">
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <span className="font-bold text-slate-900">Établissement Bancaire</span>
              </div>
              <p className="text-[10px] text-slate-500">Agence Paris Opéra • 75009 Paris</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Certificat Officiel
              </span>
              <p className="text-[11px] font-semibold text-slate-700">RIB / IBAN France</p>
            </div>
          </div>

          {/* Account Holder Info */}
          <div>
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
              Titulaire du compte
            </span>
            <p className="font-bold text-slate-900 text-sm mt-0.5">{accountHolder}</p>
            <p className="text-slate-600 text-[11px]">12 Rue de la République</p>
            <p className="text-slate-600 text-[11px]">75011 PARIS - FRANCE</p>
          </div>

          {/* RIB Breakdown Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden bg-white text-center">
            <div className="grid grid-cols-5 text-[10px] bg-slate-100 font-semibold text-slate-600 py-1.5 border-b border-slate-200">
              <div>Banque</div>
              <div>Guichet</div>
              <div className="col-span-2">N° de Compte</div>
              <div>Clé RIB</div>
            </div>
            <div className="grid grid-cols-5 py-2 font-mono font-bold text-slate-800 text-[11px]">
              <div>30004</div>
              <div>01234</div>
              <div className="col-span-2">56789012342</div>
              <div>07</div>
            </div>
          </div>

          {/* IBAN & BIC Details */}
          <div className="space-y-2 bg-white p-3.5 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  Identifiant international de compte (IBAN)
                </span>
                <span className="font-mono font-bold text-slate-900 text-xs sm:text-sm tracking-wider">
                  {account.iban}
                </span>
              </div>
              <button
                onClick={handleCopyIban}
                className="p-1.5 text-blue-700 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1 text-xs"
                title="Copier l'IBAN"
              >
                {copiedIban ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex items-center justify-between border-t border-slate-100 pt-2">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  Identifiant international de banque (BIC / SWIFT)
                </span>
                <span className="font-mono font-bold text-slate-900 text-xs sm:text-sm tracking-wider">
                  {account.bic}
                </span>
              </div>
              <button
                onClick={handleCopyBic}
                className="p-1.5 text-blue-700 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1 text-xs"
                title="Copier le BIC"
              >
                {copiedBic ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-200">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Conforme aux normes interbancaires Banque de France & FBF</span>
            </div>
            <span className="font-mono text-slate-400">Réf. ACPR: FR-30004-PARIS</span>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={handlePrint}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Imprimer</span>
          </button>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 text-xs font-semibold rounded-xl"
            >
              Fermer
            </button>
            <button
              onClick={() => {
                alert(`Le fichier PDF "RIB_${account.name.replace(/\s+/g, '_')}.pdf" a été généré.`);
                onClose();
              }}
              className="px-4 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Télécharger le PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
