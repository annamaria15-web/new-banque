import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Terminal, 
  Copy, 
  Check, 
  ExternalLink, 
  FolderArchive, 
  FileCode, 
  Sparkles,
  CheckCircle2,
  Loader2
} from 'lucide-react';

interface DownloadProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DownloadProjectModal({ isOpen, onClose }: DownloadProjectModalProps) {
  const [copied, setCopied] = useState<boolean>(false);
  const [downloading, setDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const downloadUrl = `${window.location.origin}/banque-code-source.zip`;
  const terminalCommand = `curl -LO "${downloadUrl}" && unzip -o banque-code-source.zip`;

  const handleCopyCommand = () => {
    navigator.clipboard.writeText(terminalCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleDirectDownload = async () => {
    try {
      setDownloading(true);
      setDownloadSuccess(false);

      const response = await fetch('/banque-code-source.zip');
      if (!response.ok) throw new Error('Erreur de téléchargement');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'banque-code-source.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error(err);
      // Fallback direct navigation
      window.open(downloadUrl, '_blank');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 border border-slate-100 flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#0b1c34] to-[#122849] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <FolderArchive className="w-5 h-5 text-blue-300" />
            </div>
            <div>
              <h2 className="font-bold text-base leading-tight">Télécharger le code du projet</h2>
              <p className="text-xs text-blue-200 mt-0.5">Tous les fichiers complets prêts à l'emploi</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Method 1: Instant 1-Click Browser Download */}
          <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Download className="w-3.5 h-3.5 text-blue-700" />
                Méthode 1 : Téléchargement direct (Navigateur)
              </span>
              <span className="text-[11px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
                Recommandé
              </span>
            </div>

            <p className="text-xs text-slate-600">
              Télécharge instantanément l'archive <strong>banque-code-source.zip</strong> contenant tous les dossiers et le correctif sans conflit.
            </p>

            <button
              onClick={handleDirectDownload}
              disabled={downloading}
              className="w-full py-3 px-4 bg-[#0f3d7d] hover:bg-[#0c2f61] active:scale-[0.99] text-white text-xs font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {downloading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Préparation du téléchargement...</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Téléchargement lancé avec succès !</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-blue-200" />
                  <span>Télécharger l'archive ZIP (.zip)</span>
                </>
              )}
            </button>
          </div>

          {/* Method 2: One-liner Terminal Command (Ideal for Linux / Mac) */}
          <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                Méthode 2 : Téléchargement direct dans votre terminal
              </span>
              <span className="text-[10px] text-slate-400">Linux / Mac</span>
            </div>

            <p className="text-xs text-slate-300">
              Dans votre terminal (dossier <code className="text-emerald-300 font-mono">~/Téléchargements/Banque</code>), collez cette ligne pour télécharger et extraire tous les fichiers directement :
            </p>

            <div className="bg-black/60 rounded-xl p-3 flex items-center justify-between gap-3 border border-white/10 font-mono text-[11px] text-emerald-300 overflow-x-auto">
              <span className="truncate select-all">{terminalCommand}</span>
              <button
                onClick={handleCopyCommand}
                className="shrink-0 px-2.5 py-1.5 bg-white/10 hover:bg-white/20 active:scale-95 text-white rounded-lg text-[11px] font-sans font-semibold flex items-center gap-1.5 transition-all"
                title="Copier la commande"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copié !</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copier</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Method 3: Direct Link fallback */}
          <div className="pt-1 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <FileCode className="w-3.5 h-3.5 text-slate-400" />
              Lien direct vers le fichier :
            </span>
            <a
              href={downloadUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#0f3d7d] font-semibold hover:underline flex items-center gap-1"
            >
              <span>Ouvrir le fichier ZIP</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Modal Footer with Instructions */}
        <div className="bg-slate-50 border-t border-slate-100 p-4 flex items-center justify-between text-xs text-slate-500">
          <span>Commandes : <strong className="font-mono text-slate-700">npm install</strong> puis <strong className="font-mono text-slate-700">npm run dev</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-lg transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
}
