import React, { useState } from 'react';
import { Sliders, X, Check, ShieldCheck, Lock, Unlock, Wifi, Globe } from 'lucide-react';
import { BankCard } from '../../types';

interface CardLimitsModalProps {
  isOpen: boolean;
  onClose: () => void;
  card: BankCard;
  onUpdateCard: (updated: BankCard) => void;
}

export const CardLimitsModal: React.FC<CardLimitsModalProps> = ({
  isOpen,
  onClose,
  card,
  onUpdateCard,
}) => {
  const [paymentLimit, setPaymentLimit] = useState(card.paymentLimitMax);
  const [withdrawalLimit, setWithdrawalLimit] = useState(card.withdrawalLimitMax);
  const [contactless, setContactless] = useState(card.contactlessEnabled);
  const [online, setOnline] = useState(card.onlinePaymentsEnabled);
  const [isFrozen, setIsFrozen] = useState(card.isFrozen);
  const [saved, setSaved] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateCard({
      ...card,
      paymentLimitMax: paymentLimit,
      withdrawalLimitMax: withdrawalLimit,
      contactlessEnabled: contactless,
      onlinePaymentsEnabled: online,
      isFrozen: isFrozen,
    });

    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Gestion des plafonds de carte</h3>
              <p className="text-[11px] text-slate-500">Carte {card.network} •••• {card.lastFour}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {saved && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-xl text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>Nouveaux plafonds activés immédiatement !</span>
          </div>
        )}

        <div className="space-y-5 text-xs">
          {/* Payment Slider */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <span className="font-semibold text-slate-700">Plafond de paiements (30j)</span>
              <span className="font-bold text-blue-900 text-sm">{paymentLimit} €</span>
            </div>
            <input
              type="range"
              min="500"
              max="6000"
              step="100"
              value={paymentLimit}
              onChange={(e) => setPaymentLimit(Number(e.target.value))}
              className="w-full accent-blue-800"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>Min : 500 €</span>
              <span>Actuel utilisé : {card.paymentLimitSpent} €</span>
              <span>Max : 6 000 €</span>
            </div>
          </div>

          {/* Withdrawal Slider */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <span className="font-semibold text-slate-700">Plafond de retraits (7j)</span>
              <span className="font-bold text-blue-900 text-sm">{withdrawalLimit} €</span>
            </div>
            <input
              type="range"
              min="200"
              max="2500"
              step="50"
              value={withdrawalLimit}
              onChange={(e) => setWithdrawalLimit(Number(e.target.value))}
              className="w-full accent-blue-800"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>Min : 200 €</span>
              <span>Actuel utilisé : {card.withdrawalLimitSpent} €</span>
              <span>Max : 2 500 €</span>
            </div>
          </div>

          {/* Toggles */}
          <div className="pt-2 border-t border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4 text-blue-600 rotate-90" />
                <span>Paiements sans contact</span>
              </div>
              <input
                type="checkbox"
                checked={contactless}
                onChange={(e) => setContactless(e.target.checked)}
                className="w-4 h-4 accent-blue-800 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-600" />
                <span>Paiements sur internet</span>
              </div>
              <input
                type="checkbox"
                checked={online}
                onChange={(e) => setOnline(e.target.checked)}
                className="w-4 h-4 accent-blue-800 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isFrozen ? <Lock className="w-4 h-4 text-rose-600" /> : <Unlock className="w-4 h-4 text-emerald-600" />}
                <span>Verrouiller temporairement la carte</span>
              </div>
              <input
                type="checkbox"
                checked={isFrozen}
                onChange={(e) => setIsFrozen(e.target.checked)}
                className="w-4 h-4 accent-rose-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50"
          >
            Annuler
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-bold rounded-xl shadow-sm transition-all"
          >
            Enregistrer les modifications
          </button>
        </div>
      </div>
    </div>
  );
};
