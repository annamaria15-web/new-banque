import React, { useState } from 'react';
import { Send, Zap, Clock, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { BankAccount, Beneficiary } from '../../types';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: BankAccount[];
  beneficiaries: Beneficiary[];
  defaultFromAccountId?: string;
  onExecuteTransfer: (data: {
    fromAccountId: string;
    toIban: string;
    beneficiaryName: string;
    amount: number;
    instant: boolean;
    reason: string;
  }) => void;
}

export const TransferModal: React.FC<TransferModalProps> = ({
  isOpen,
  onClose,
  accounts,
  beneficiaries,
  defaultFromAccountId,
  onExecuteTransfer,
}) => {
  const [fromAccountId, setFromAccountId] = useState(defaultFromAccountId || accounts[0]?.id || '');
  const [selectedBenId, setSelectedBenId] = useState(beneficiaries[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [isInstant, setIsInstant] = useState(true);
  const [reason, setReason] = useState('');

  if (!isOpen) return null;

  const selectedAccount = accounts.find(a => a.id === fromAccountId) || accounts[0];
  const selectedBeneficiary = beneficiaries.find(b => b.id === selectedBenId) || beneficiaries[0];
  const numAmount = parseFloat(amount.replace(',', '.')) || 0;
  const isBalanceSufficient = selectedAccount ? selectedAccount.balance >= numAmount : false;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBeneficiary || numAmount <= 0 || !isBalanceSufficient) return;

    onExecuteTransfer({
      fromAccountId: selectedAccount.id,
      toIban: selectedBeneficiary.iban,
      beneficiaryName: selectedBeneficiary.name,
      amount: numAmount,
      instant: isInstant,
      reason: reason || 'Virement bancaire',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <Send className="w-4 h-4 rotate-[-20deg]" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Nouveau virement</h3>
              <p className="text-[11px] text-slate-500">Immédiat et sécurisé SEPA</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Compte à débiter</label>
            <select
              value={fromAccountId}
              onChange={(e) => setFromAccountId(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 font-medium"
            >
              {accounts.map(acc => (
                <option key={acc.id} value={acc.id}>
                  {acc.name} — Solde disponible : {acc.balance.toFixed(2)} €
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Bénéficiaire crédité</label>
            <select
              value={selectedBenId}
              onChange={(e) => setSelectedBenId(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 font-medium"
            >
              {beneficiaries.map(ben => (
                <option key={ben.id} value={ben.id}>
                  {ben.name} ({ben.nickname || ben.bankName})
                </option>
              ))}
            </select>
            {selectedBeneficiary && (
              <p className="text-[11px] text-slate-400 font-mono mt-1">
                IBAN : {selectedBeneficiary.iban}
              </p>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Montant du virement (€)</label>
            <div className="relative">
              <input
                type="text"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 text-base font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 pr-10"
              />
              <span className="absolute right-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                €
              </span>
            </div>
            {numAmount > 0 && !isBalanceSufficient && (
              <p className="text-red-600 text-[11px] mt-1 font-medium">
                Solde insuffisant sur le compte sélectionné.
              </p>
            )}
          </div>

          {/* Transfer Type */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1.5">Délai d'exécution</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIsInstant(true)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isInstant ? 'border-emerald-600 bg-emerald-50/50 text-emerald-950 font-bold' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  <Zap className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-xs">Instantané SEPA</span>
                </div>
                <p className="text-[10px] text-slate-500 font-normal">Reçu en 10 secondes (Gratuit)</p>
              </button>

              <button
                type="button"
                onClick={() => setIsInstant(false)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  !isInstant ? 'border-blue-700 bg-blue-50/50 text-blue-950 font-bold' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  <Clock className="w-3.5 h-3.5 text-blue-600" />
                  <span className="text-xs">Standard SEPA</span>
                </div>
                <p className="text-[10px] text-slate-500 font-normal">1 à 2 jours ouvrés</p>
              </button>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Motif (facultatif)</label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ex : Remboursement, Loyer, Épargne"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>

          <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 flex items-center justify-between text-[11px] text-slate-600">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Transfert crypté & sécurisé DSP2
            </span>
            <span className="font-mono text-slate-400 text-[10px]">Frais : 0,00 €</span>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={numAmount <= 0 || !isBalanceSufficient}
              className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] disabled:bg-slate-300 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
            >
              <span>Valider le virement</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
