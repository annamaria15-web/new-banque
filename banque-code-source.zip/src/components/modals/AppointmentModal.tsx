import React, { useState } from 'react';
import { Calendar, Clock, Video, Phone, Building2, CheckCircle2, X } from 'lucide-react';
import { AdvisorInfo } from '../../types';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  advisor: AdvisorInfo;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  advisor,
}) => {
  const [meetingType, setMeetingType] = useState<'agency' | 'phone' | 'video'>('agency');
  const [motive, setMotive] = useState('Bilan d’épargne & Placements');
  const [selectedDate, setSelectedDate] = useState('2025-09-25');
  const [selectedSlot, setSelectedSlot] = useState('14:30');
  const [booked, setBooked] = useState(false);

  if (!isOpen) return null;

  const timeSlots = ['09:30', '11:00', '14:30', '16:00', '17:15'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBooked(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Prendre rendez-vous</h3>
              <p className="text-[11px] text-slate-500">Avec {advisor.name} ({advisor.title})</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {booked ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-base font-bold text-slate-900">Rendez-vous confirmé !</h4>
            <p className="text-xs text-slate-600 max-w-sm mx-auto">
              Votre rendez-vous pour <strong>{motive}</strong> est réservé le <strong>{selectedDate}</strong> à <strong>{selectedSlot}</strong>.
            </p>
            <div className="bg-slate-50 p-3 rounded-xl text-xs text-slate-500 text-left border border-slate-200">
              <p>• Type : {meetingType === 'agency' ? `En agence (${advisor.agency})` : meetingType === 'phone' ? 'Par téléphone (01 23...)' : 'En visioconférence sécurisée'}</p>
              <p>• Un rappel vous sera envoyé par SMS et par e-mail 24h avant.</p>
            </div>
            <button
              onClick={() => {
                setBooked(false);
                onClose();
              }}
              className="mt-4 px-6 py-2 bg-[#0f3d7d] text-white text-xs font-bold rounded-xl"
            >
              Compris
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Format choice */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Mode d'échange</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setMeetingType('agency')}
                  className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 ${
                    meetingType === 'agency' ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-blue-700" />
                  <span>En agence</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMeetingType('phone')}
                  className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 ${
                    meetingType === 'phone' ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <Phone className="w-4 h-4 text-blue-700" />
                  <span>Téléphone</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMeetingType('video')}
                  className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 ${
                    meetingType === 'video' ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <Video className="w-4 h-4 text-blue-700" />
                  <span>Visioconférence</span>
                </button>
              </div>
            </div>

            {/* Motive */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Motif de la rencontre</label>
              <select
                value={motive}
                onChange={(e) => setMotive(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 font-medium"
              >
                <option value="Bilan d’épargne & Placements">Bilan d’épargne & Placements</option>
                <option value="Projet immobilier / Achat">Projet immobilier / Achat</option>
                <option value="Crédit auto ou travaux">Crédit auto ou travaux</option>
                <option value="Assurance et prévoyance">Assurance et prévoyance</option>
                <option value="Gestion courante des comptes">Gestion courante des comptes</option>
              </select>
            </div>

            {/* Date and Time slots */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Date</label>
                <input
                  type="date"
                  value={selectedDate}
                  min="2025-09-23"
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Créneau horaire</label>
                <div className="grid grid-cols-3 gap-1">
                  {timeSlots.map(slot => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedSlot(slot)}
                      className={`p-1.5 rounded-lg border text-center font-medium ${
                        selectedSlot === slot ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white font-bold rounded-xl shadow-sm transition-all"
              >
                Confirmer le rendez-vous
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
