import React, { useState } from 'react';
import { Clock, CheckCircle2, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { BankTransaction } from '../../types';

interface SpreadPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction?: BankTransaction;
}

export const SpreadPaymentModal: React.FC<SpreadPaymentModalProps> = ({
  isOpen,
  onClose,
  transaction,
}) => {
  const [installments, setInstallments] = useState<3 | 4>(3);
  const [confirmed, setConfirmed] = useState(false);

  if (!isOpen) return null;

  const rawAmount = transaction ? Math.abs(transaction.amount) : 150.00;
  const monthly = (rawAmount / installments).toFixed(2);

  const handleConfirm = () => {
    setConfirmed(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Étaler un débit</h3>
              <p className="text-[11px] text-slate-500">Paiement fractionné sans frais cachés</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmed ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-base font-bold text-slate-900">Étalement validé !</h4>
            <p className="text-xs text-slate-600 max-w-xs mx-auto">
              Votre débit de {rawAmount.toFixed(2)} € est désormais réparti en {installments} mensualités de {monthly} €. Votre compte est recrédité immédiatement de la différence.
            </p>
            <button
              onClick={() => {
                setConfirmed(false);
                onClose();
              }}
              className="mt-3 px-5 py-2 bg-[#0f3d7d] text-white text-xs font-bold rounded-xl"
            >
              Terminer
            </button>
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Dépense sélectionnée :</span>
                <span className="font-bold text-slate-900">{transaction?.label || 'Dépense courante'}</span>
              </div>
              <div className="flex justify-between items-center mt-1">
                <span className="text-slate-500">Montant total :</span>
                <span className="text-base font-extrabold text-blue-900">{rawAmount.toFixed(2)} €</span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">
                Choisissez le nombre d'échéances
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setInstallments(3)}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    installments === 3 ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200'
                  }`}
                >
                  <p className="text-base font-extrabold">3 fois</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">{monthly} € / mois</p>
                </button>
                <button
                  type="button"
                  onClick={() => setInstallments(4)}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    installments === 4 ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200'
                  }`}
                >
                  <p className="text-base font-extrabold">4 fois</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">{monthly} € / mois</p>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-[11px] text-slate-600">
              <div className="flex justify-between font-semibold text-slate-800">
                <span>1ère échéance (aujourd'hui) :</span>
                <span>{monthly} €</span>
              </div>
              <div className="flex justify-between">
                <span>2ème échéance (22 oct. 2025) :</span>
                <span>{monthly} €</span>
              </div>
              <div className="flex justify-between">
                <span>3ème échéance (22 nov. 2025) :</span>
                <span>{monthly} €</span>
              </div>
              {installments === 4 && (
                <div className="flex justify-between">
                  <span>4ème échéance (22 déc. 2025) :</span>
                  <span>{monthly} €</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleConfirm}
                className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white font-bold rounded-xl shadow-sm transition-all"
              >
                Valider l'étalement
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
