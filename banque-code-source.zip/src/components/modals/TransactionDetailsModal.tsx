import React from 'react';
import { ArrowDownLeft, ArrowUpRight, CheckCircle2, Download, X } from 'lucide-react';
import { BankTransaction } from '../../types';

interface TransactionDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: BankTransaction | null;
}

export const TransactionDetailsModal: React.FC<TransactionDetailsModalProps> = ({
  isOpen,
  onClose,
  transaction,
}) => {
  if (!isOpen || !transaction) return null;

  const isCredit = transaction.amount > 0;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isCredit ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-700'
            }`}>
              {isCredit ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Détail de l'opération</h3>
              <p className="text-[11px] text-slate-500">{transaction.formattedDate}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Amount Box */}
        <div className="text-center py-4 bg-slate-50 rounded-xl border border-slate-100">
          <span className="text-xs text-slate-400 uppercase tracking-wider block mb-1">
            Montant comptabilisé
          </span>
          <div className={`text-3xl font-black ${isCredit ? 'text-emerald-600' : 'text-slate-900'}`}>
            {isCredit ? `+ ${transaction.amount.toFixed(2)} €` : `${transaction.amount.toFixed(2)} €`}
          </div>
          <p className="text-xs text-slate-500 font-mono mt-1">
            Solde après opération : {transaction.balanceAfter.toFixed(2)} €
          </p>
        </div>

        {/* Details list */}
        <div className="space-y-2.5 text-xs text-slate-600">
          <div className="flex justify-between py-1.5 border-b border-slate-100">
            <span className="text-slate-400">Libellé :</span>
            <span className="font-bold text-slate-800 text-right">{transaction.label}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-100">
            <span className="text-slate-400">Tiers / Émetteur :</span>
            <span className="font-medium text-slate-800">{transaction.counterparty || 'Non spécifié'}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-100">
            <span className="text-slate-400">Référence bancaire :</span>
            <span className="font-mono text-slate-800">{transaction.reference || 'TX-99410'}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-100">
            <span className="text-slate-400">Statut :</span>
            <span className="font-semibold text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Exécuté & validé
            </span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-100">
            <span className="text-slate-400">Canal :</span>
            <span className="text-slate-800 font-medium">Espace Web Sécurisé</span>
          </div>
        </div>

        <div className="flex justify-between items-center pt-3 border-t border-slate-100">
          <button
            onClick={() => {
              alert(`Le justificatif d'opération ${transaction.reference || 'REF-TX'} a été téléchargé.`);
            }}
            className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Reçu PDF</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white text-xs font-bold rounded-xl"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
