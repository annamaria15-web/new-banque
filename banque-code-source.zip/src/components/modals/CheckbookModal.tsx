import React, { useState } from 'react';
import { CheckSquare, CheckCircle2, X, MapPin, Mail } from 'lucide-react';

interface CheckbookModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckbookModal: React.FC<CheckbookModalProps> = ({ isOpen, onClose }) => {
  const [format, setFormat] = useState('portefeuille');
  const [delivery, setDelivery] = useState('domicile');
  const [ordered, setOrdered] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOrdered(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <CheckSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Commander un chéquier</h3>
              <p className="text-[11px] text-slate-500">Pour votre C/C Contrat Personnel</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {ordered ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-base font-bold text-slate-900">Commande enregistrée !</h4>
            <p className="text-xs text-slate-600 max-w-xs mx-auto">
              Votre chéquier (format {format}) sera {delivery === 'domicile' ? 'expédié à votre adresse sous 5 jours ouvrés' : 'disponible en agence Paris Opéra sous 3 jours'}.
            </p>
            <button
              onClick={() => {
                setOrdered(false);
                onClose();
              }}
              className="mt-3 px-5 py-2 bg-[#0f3d7d] text-white text-xs font-bold rounded-xl"
            >
              Fermer
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Format du carnet</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setFormat('portefeuille')}
                  className={`p-2.5 rounded-xl border text-left ${
                    format === 'portefeuille' ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200'
                  }`}
                >
                  <p>Portefeuille (talon haut)</p>
                  <p className="text-[10px] text-slate-500 font-normal">25 chèques</p>
                </button>
                <button
                  type="button"
                  onClick={() => setFormat('correspondance')}
                  className={`p-2.5 rounded-xl border text-left ${
                    format === 'correspondance' ? 'bg-blue-50 border-blue-800 text-blue-900 font-bold' : 'border-slate-200'
                  }`}
                >
                  <p>Correspondance (talon gauche)</p>
                  <p className="text-[10px] text-slate-500 font-normal">40 chèques</p>
                </button>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Mode de délivrance</label>
              <div className="space-y-2">
                <div
                  onClick={() => setDelivery('domicile')}
                  className={`p-3 rounded-xl border cursor-pointer flex items-center gap-3 ${
                    delivery === 'domicile' ? 'bg-blue-50 border-blue-800 ring-1 ring-blue-800' : 'border-slate-200'
                  }`}
                >
                  <Mail className="w-4 h-4 text-blue-700 shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-900">Envoi postal à domicile</p>
                    <p className="text-[11px] text-slate-500">12 Rue de la République, 75011 Paris</p>
                  </div>
                </div>

                <div
                  onClick={() => setDelivery('agence')}
                  className={`p-3 rounded-xl border cursor-pointer flex items-center gap-3 ${
                    delivery === 'agence' ? 'bg-blue-50 border-blue-800 ring-1 ring-blue-800' : 'border-slate-200'
                  }`}
                >
                  <MapPin className="w-4 h-4 text-blue-700 shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-900">Retrait en agence</p>
                    <p className="text-[11px] text-slate-500">Agence Paris Opéra (gratuit)</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white font-bold rounded-xl shadow-sm transition-all"
              >
                Commander
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
