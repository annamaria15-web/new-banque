import React, { useState } from 'react';
import { UserPlus, X, Check, Building2 } from 'lucide-react';
import { Beneficiary } from '../../types';

interface BeneficiaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddBeneficiary: (beneficiary: Beneficiary) => void;
}

export const BeneficiaryModal: React.FC<BeneficiaryModalProps> = ({
  isOpen,
  onClose,
  onAddBeneficiary,
}) => {
  const [name, setName] = useState('');
  const [nickname, setNickname] = useState('');
  const [iban, setIban] = useState('');
  const [bic, setBic] = useState('BNPAFRPPXXX');
  const [bankName, setBankName] = useState('BNP Paribas');
  const [category, setCategory] = useState('Amis & Famille');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !iban.trim()) return;

    const newBen: Beneficiary = {
      id: `ben-${Date.now()}`,
      name: name.trim(),
      nickname: nickname.trim() || undefined,
      iban: iban.trim().toUpperCase(),
      bic: bic.trim().toUpperCase(),
      bankName: bankName.trim(),
      category: category,
      lastTransferDate: 'Aujourd’hui',
    };

    onAddBeneficiary(newBen);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Ajouter un bénéficiaire</h3>
              <p className="text-[11px] text-slate-500">Enregistrement sécurisé de RIB tiers</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Nom et Prénom du titulaire *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex : Martin Dupont"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Surnom ou Libellé personnalisé (facultatif)
            </label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="Ex : Martin Coloc, Salle de sport..."
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              IBAN du bénéficiaire *
            </label>
            <input
              type="text"
              required
              value={iban}
              onChange={(e) => setIban(e.target.value)}
              placeholder="FR76 1234 5678 9012 3456 7890 123"
              className="w-full p-2.5 font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 uppercase"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">BIC / SWIFT</label>
              <input
                type="text"
                required
                value={bic}
                onChange={(e) => setBic(e.target.value)}
                placeholder="BNPAFRPPXXX"
                className="w-full p-2.5 font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 uppercase"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Banque</label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="BNP Paribas"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Catégorie</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-700 font-medium"
            >
              <option value="Amis & Famille">Amis & Famille</option>
              <option value="Logement">Logement & Charges</option>
              <option value="Factures">Factures & Abonnements</option>
              <option value="Professionnel">Professionnel</option>
              <option value="Autre">Autre</option>
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0f3d7d] hover:bg-[#0c2f61] text-white font-bold rounded-xl shadow-sm transition-all"
            >
              Enregistrer le bénéficiaire
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
