import React from 'react';
import { Headphones, Phone, Mail, ShieldAlert, MessageCircle, X } from 'lucide-react';

interface HelpContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAdvisor: () => void;
}

export const HelpContactModal: React.FC<HelpContactModalProps> = ({
  isOpen,
  onClose,
  onOpenAdvisor,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
              <Headphones className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Centre d'aide & Assistance</h3>
              <p className="text-[11px] text-slate-500">Nos équipes à vos côtés</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          {/* Opposition urgence */}
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-rose-900">Perte ou vol de carte bancaire</h4>
              <p className="text-rose-700 text-[11px] mt-0.5">
                Service d'opposition 24h/24 et 7j/7 gratuit :
              </p>
              <a href="tel:0800040404" className="font-bold text-rose-900 hover:underline mt-1 block">
                0 800 04 04 04 (Numéro Vert)
              </a>
            </div>
          </div>

          {/* Conseiller dédié */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3">
            <MessageCircle className="w-5 h-5 text-blue-800 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-bold text-slate-900">Votre conseillère clientèle</h4>
              <p className="text-slate-600 text-[11px] mt-0.5">
                Mme Claire Dubois — Agence Paris Opéra
              </p>
              <button
                onClick={() => {
                  onClose();
                  onOpenAdvisor();
                }}
                className="mt-2 text-xs font-semibold text-blue-800 hover:text-blue-950 underline"
              >
                Ouvrir la messagerie sécurisée →
              </button>
            </div>
          </div>

          {/* Service Client général */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3">
            <Phone className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-slate-900">Assistance en ligne & Technique</h4>
              <p className="text-slate-500 text-[11px]">
                Du lundi au vendredi de 8h00 à 19h00, samedi de 9h00 à 14h00.
              </p>
              <p className="font-semibold text-slate-800 mt-1">39 21 (service gratuit + prix appel)</p>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#0f3d7d] text-white text-xs font-bold rounded-xl"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
