import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  Info, 
  Send, 
  FileDown, 
  Sliders, 
  Clock, 
  ChevronRight, 
  PiggyBank, 
  Building2, 
  FileText, 
  Calendar,
  CreditCard,
  UserPlus,
  CheckSquare,
  Phone,
  Mail,
  MoreVertical,
  ArrowUpRight,
  ArrowDownLeft,
  Smartphone,
  ShieldCheck,
  Landmark,
  ShieldAlert
} from 'lucide-react';
import { AdvisorInfo, BankAccount, BankCard, BankTransaction, NavigationTab } from '../types';

interface DashboardViewProps {
  accounts: BankAccount[];
  transactions: BankTransaction[];
  cards: BankCard[];
  advisor: AdvisorInfo;
  onNavigate: (tab: NavigationTab) => void;
  onOpenTransfer: (fromAccountId?: string) => void;
  onOpenRib: (account?: BankAccount) => void;
  onOpenCardLimits: (card?: BankCard) => void;
  onOpenBeneficiary: () => void;
  onOpenAppointment: () => void;
  onOpenCheckbook: () => void;
  onOpenSpreadPayment?: (transaction?: BankTransaction) => void;
  onSelectTransaction: (tx: BankTransaction) => void;
  accountHolder?: string;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  accounts,
  transactions,
  cards,
  advisor,
  onNavigate,
  onOpenTransfer,
  onOpenRib,
  onOpenCardLimits,
  onOpenBeneficiary,
  onOpenAppointment,
  onOpenCheckbook,
  onOpenSpreadPayment,
  onSelectTransaction,
  accountHolder = 'Client',
}) => {
  const [copiedIban, setCopiedIban] = useState(false);
  const firstName = accountHolder.split(' ')[0] || accountHolder;
  const [selectedCardIdx, setSelectedCardIdx] = useState(0);
  const [activeMenuTxId, setActiveMenuTxId] = useState<string | null>(null);

  const primaryAccount = accounts.find(a => a.isPrincipal) || accounts[0];
  const savingsAccounts = accounts.filter(a => !a.isPrincipal);
  const currentCard = cards[selectedCardIdx] || cards[0];

  const handleCopyIban = () => {
    navigator.clipboard.writeText(primaryAccount.iban);
    setCopiedIban(true);
    setTimeout(() => setCopiedIban(false), 2000);
  };

  // Formatter for French currency format: 1 234,56 €
  const formatEuro = (val: number, showSign: boolean = false) => {
    const formatted = new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 2,
    }).format(Math.abs(val));

    if (showSign) {
      return val >= 0 ? `+ ${formatted}` : `- ${formatted}`;
    }
    return formatted;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Greeting & French Date */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-[26px] font-bold text-slate-900 tracking-tight">
            Bonjour, {firstName}
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Bienvenue sur votre espace bancaire sécurisé.
          </p>
        </div>

        <div className="self-start sm:self-auto flex items-center gap-2 px-3.5 py-1.5 bg-white border border-slate-200/90 rounded-xl text-xs text-slate-600 shadow-sm">
          <Calendar className="w-3.5 h-3.5 text-blue-800" />
          <span className="font-medium">Lundi 22 septembre 2025</span>
          <span className="text-slate-300">|</span>
          <span className="text-[11px] text-slate-500">Agence Paris Opéra</span>
        </div>
      </div>

      {/* Main Grid: Left 2 Cols (Hero + Operations) + Right 1 Col (Quick actions & Advisor) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (8 cols on lg) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Main Hero Account Card */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0c397c] via-[#0e4494] to-[#0a2f68] text-white shadow-xl shadow-blue-950/20">
            {/* Background Watermark Architecture / Bank Columns */}
            <div className="absolute right-4 top-3 pointer-events-none opacity-20 text-white flex flex-col items-center">
              <Landmark className="w-16 h-16 stroke-[1.2]" />
              <span className="text-[10px] tracking-widest uppercase mt-0.5 font-light">
                Banque de détail France
              </span>
            </div>

            <div className="p-6 sm:p-7 relative z-10">
              {/* Account Meta */}
              <div className="flex flex-wrap items-center gap-2.5 mb-2">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-blue-200" />
                  <span className="text-sm sm:text-base font-semibold tracking-wide">
                    {primaryAccount.name}
                  </span>
                </div>
                <span className="bg-white/20 hover:bg-white/25 transition-colors text-white text-[11px] font-medium px-2.5 py-0.5 rounded-full backdrop-blur-sm">
                  Compte de dépôt principal
                </span>
                <span className="bg-emerald-500/20 text-emerald-200 text-[10px] font-semibold px-2 py-0.5 rounded border border-emerald-400/30">
                  Garantie FGDR
                </span>
              </div>

              {/* IBAN Row with French bank format */}
              <div className="flex items-center gap-2 text-xs text-blue-200 mb-6 font-mono">
                <span>IBAN :</span>
                <span className="tracking-wider">{primaryAccount.maskedIban}</span>
                <button
                  onClick={handleCopyIban}
                  className="p-1 hover:bg-white/10 rounded transition-colors text-blue-100 flex items-center gap-1"
                  title="Copier l'IBAN complet"
                >
                  {copiedIban ? (
                    <span className="text-[11px] font-sans text-emerald-300 flex items-center gap-1 font-semibold">
                      <Check className="w-3.5 h-3.5" /> Copié
                    </span>
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              {/* Balance display */}
              <div className="my-4">
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight">
                  + {formatEuro(primaryAccount.balance)}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-blue-200 mt-1">
                  <span>Solde disponible en temps réel</span>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-blue-300 hover:text-white transition-colors" />
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block w-56 p-2 bg-slate-900 text-white text-[11px] rounded shadow-lg text-center z-20">
                      Montant utilisable immédiatement après déduction des autorisations CB et prélèvements SEPA du jour.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions Bar along bottom of hero card */}
            <div className="bg-[#08234e]/85 backdrop-blur-md px-4 sm:px-6 py-3 border-t border-white/10 flex items-center justify-between overflow-x-auto text-xs font-medium">
              <div className="flex items-center gap-4 sm:gap-6 min-w-max">
                <button
                  onClick={() => onOpenTransfer(primaryAccount.id)}
                  className="flex items-center gap-2 text-white hover:text-blue-200 transition-colors py-1"
                >
                  <Send className="w-3.5 h-3.5 rotate-[-20deg]" />
                  <span>Virement SEPA</span>
                </button>
                <button
                  onClick={() => onOpenRib(primaryAccount)}
                  className="flex items-center gap-2 text-white hover:text-blue-200 transition-colors py-1"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Télécharger RIB (PDF)</span>
                </button>
                <button
                  onClick={() => onOpenCardLimits(currentCard)}
                  className="flex items-center gap-2 text-white hover:text-blue-200 transition-colors py-1"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Plafonds Carte CB</span>
                </button>
                <button
                  onClick={() => onOpenSpreadPayment && onOpenSpreadPayment()}
                  className="flex items-center gap-2 text-white hover:text-blue-200 transition-colors py-1"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Étaler en 3x ou 4x</span>
                </button>
              </div>

              <button 
                onClick={() => onNavigate('accounts')}
                className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded transition-colors ml-2"
                title="Consulter le relevé de compte"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 3 Savings Cards Row: French Regulated Savings Products */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {savingsAccounts.map((acc, index) => {
              const icons = [PiggyBank, Building2, FileText];
              const IconComp = icons[index % icons.length];

              return (
                <div
                  key={acc.id}
                  onClick={() => onNavigate('savings')}
                  className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-9 h-9 rounded-xl bg-blue-50 group-hover:bg-blue-100 text-[#0c397c] flex items-center justify-center transition-colors">
                        <IconComp className="w-4 h-4" />
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 transition-colors" />
                    </div>
                    <h3 className="text-xs font-semibold text-slate-700 group-hover:text-[#0c397c] transition-colors line-clamp-1">
                      {acc.name}
                    </h3>
                    <p className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                      + {formatEuro(acc.balance)}
                    </p>
                  </div>
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Taux réglementé :</span>
                    <span className="font-semibold text-emerald-600">{acc.rate?.toFixed(2)}% net</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Mid Section: Recent Transactions & Card */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            
            {/* Dernières opérations Table (7 cols on md) */}
            <div className="md:col-span-7 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      Dernières opérations
                    </h2>
                    <p className="text-[11px] text-slate-400">
                      Écritures enregistrées en euros (€)
                    </p>
                  </div>
                  <button
                    onClick={() => onNavigate('accounts')}
                    className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center gap-1 group"
                  >
                    <span>Voir tout l'historique</span>
                    <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </button>
                </div>

                {/* Table Header */}
                <div className="grid grid-cols-12 gap-2 text-[11px] font-semibold text-slate-400 uppercase py-2.5 tracking-wider border-b border-slate-100">
                  <div className="col-span-3">Date</div>
                  <div className="col-span-4">Libellé / Tiers</div>
                  <div className="col-span-3 text-right">Montant</div>
                  <div className="col-span-2 text-right">Solde</div>
                </div>

                {/* Transactions Rows */}
                <div className="divide-y divide-slate-100">
                  {transactions.slice(0, 5).map((tx) => {
                    const isCredit = tx.amount > 0;
                    return (
                      <div
                        key={tx.id}
                        className="grid grid-cols-12 gap-2 py-3 items-center hover:bg-slate-50/80 rounded-lg px-1 transition-colors group cursor-pointer text-xs"
                        onClick={() => onSelectTransaction(tx)}
                      >
                        {/* Date with icon */}
                        <div className="col-span-3 flex items-center gap-2 text-slate-600">
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                              isCredit 
                                ? 'bg-emerald-50 text-emerald-600' 
                                : tx.category === 'cash' 
                                ? 'bg-rose-50 text-rose-600' 
                                : 'bg-blue-50 text-blue-600'
                            }`}
                          >
                            {isCredit ? (
                              <ArrowDownLeft className="w-3 h-3" />
                            ) : (
                              <ArrowUpRight className="w-3 h-3" />
                            )}
                          </div>
                          <span className="text-[11px] truncate font-medium">
                            {tx.formattedDate.replace(' 2025', '')}
                          </span>
                        </div>

                        {/* Libellé */}
                        <div className="col-span-4">
                          <p className="font-semibold text-slate-800 truncate" title={tx.label}>
                            {tx.label}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate">
                            {tx.counterparty || 'Opération par carte'}
                          </p>
                        </div>

                        {/* Montant */}
                        <div className={`col-span-3 text-right font-bold ${
                          isCredit ? 'text-emerald-600' : 'text-slate-900'
                        }`}>
                          {isCredit ? `+ ${formatEuro(tx.amount)}` : `- ${formatEuro(Math.abs(tx.amount))}`}
                        </div>

                        {/* Solde & 3-dots */}
                        <div className="col-span-2 flex items-center justify-end gap-1 text-slate-500 font-mono text-[11px]">
                          <span className="truncate">{formatEuro(tx.balanceAfter)}</span>
                          <div className="relative">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveMenuTxId(activeMenuTxId === tx.id ? null : tx.id);
                              }}
                              className="p-1 hover:bg-slate-200/70 rounded text-slate-400 hover:text-slate-600"
                            >
                              <MoreVertical className="w-3.5 h-3.5" />
                            </button>

                            {activeMenuTxId === tx.id && (
                              <div className="absolute right-0 mt-1 w-48 bg-white rounded-lg shadow-xl border border-slate-200 py-1 z-30 text-left font-sans">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onSelectTransaction(tx);
                                    setActiveMenuTxId(null);
                                  }}
                                  className="w-full px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                                >
                                  <FileText className="w-3.5 h-3.5" /> Détail & Reçu d'opération
                                </button>
                                {tx.amount < -50 && onOpenSpreadPayment && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onOpenSpreadPayment(tx);
                                      setActiveMenuTxId(null);
                                    }}
                                    className="w-full px-3 py-1.5 text-xs text-blue-700 hover:bg-blue-50 flex items-center gap-2"
                                  >
                                    <Clock className="w-3.5 h-3.5" /> Étaler en 3x ou 4x
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Ma carte bancaire Card with authentic French CB badge */}
            <div className="md:col-span-5 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-base font-bold text-slate-900">
                    Ma carte bancaire CB
                  </h2>
                  <span className="text-[10px] bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">
                    Réseau CB France
                  </span>
                </div>

                {/* Realistic French Bank Card Visual */}
                <div className="relative w-full aspect-[1.586/1] rounded-2xl p-5 text-white shadow-lg shadow-slate-900/20 overflow-hidden bg-gradient-to-tr from-[#0a182d] via-[#102a52] to-[#0c1f3a] select-none">
                  {/* Subtle Background Pattern */}
                  <div className="absolute -right-8 -bottom-8 w-44 h-44 rounded-full bg-blue-500/10 blur-xl pointer-events-none" />
                  
                  {/* Card Header: Chip, Contactless */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-xs tracking-tight text-white/90">
                        Carte Particulier
                      </span>
                    </div>

                    {/* Chip & Contactless waves */}
                    <div className="flex items-center gap-2">
                      {/* EMV Chip representation */}
                      <div className="w-7 h-5 rounded bg-gradient-to-br from-amber-200 to-amber-400 border border-amber-500/50 flex items-center justify-center shadow-xs">
                        <div className="w-full h-full border border-amber-600/30 rounded-xs flex items-center justify-center">
                          <div className="w-3 h-2 border border-amber-700/30" />
                        </div>
                      </div>

                      <div className="flex items-center gap-1 opacity-80">
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                          <path d="M8.5 16.5a5 5 0 0 1 0-9" />
                          <path d="M12 19a8.5 8.5 0 0 1 0-14" />
                          <path d="M15.5 21.5a12 12 0 0 1 0-19" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Card Number Masked */}
                  <div className="mt-5 mb-2">
                    <div className="font-mono text-base sm:text-lg tracking-[0.25em] text-slate-100 flex items-center justify-between">
                      <span>••••</span>
                      <span>••••</span>
                      <span>••••</span>
                      <span className="font-bold text-white">{currentCard.lastFour}</span>
                    </div>
                  </div>

                  {/* Card Mention: DEBIT IMMEDIAT (Mandatory on French payment cards) */}
                  <div className="text-[9px] font-bold text-blue-200/90 tracking-widest uppercase">
                    DÉBIT IMMÉDIAT
                  </div>

                  {/* Card Footer: Expiry & Dual CB / VISA logos */}
                  <div className="flex items-end justify-between mt-auto pt-2">
                    <div>
                      <p className="text-[8px] text-slate-400 uppercase tracking-widest">
                        Expire fin
                      </p>
                      <p className="font-mono text-xs font-semibold tracking-wider text-slate-200">
                        {currentCard.expiry}
                      </p>
                    </div>

                    {/* Dual CB and VISA logos (Iconic French co-badged card) */}
                    <div className="flex items-center gap-2">
                      {/* Authentic French Cartes Bancaires (CB) Badge */}
                      <div className="bg-[#00704a] text-white font-extrabold text-[10px] px-1.5 py-0.5 rounded tracking-wider flex items-center shadow-xs border border-emerald-400/40">
                        CB
                      </div>
                      <span className="font-black italic text-lg sm:text-xl tracking-wider text-white">
                        VISA
                      </span>
                    </div>
                  </div>
                </div>

                {/* Carousel Pagination Dots */}
                <div className="flex items-center justify-center gap-2 mt-4">
                  {cards.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedCardIdx(idx)}
                      className={`h-2 rounded-full transition-all ${
                        selectedCardIdx === idx 
                          ? 'w-6 bg-[#0f3d7d]' 
                          : 'w-2 bg-slate-300 hover:bg-slate-400'
                      }`}
                      title={`Carte ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>

              {/* Action Button: Voir les détails */}
              <button
                onClick={() => onOpenCardLimits(currentCard)}
                className="w-full mt-4 py-2.5 px-4 border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors group"
              >
                <span>Gérer les plafonds & options</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Lower 3 Cards Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Mes documents */}
            <div 
              onClick={() => onNavigate('documents')}
              className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0f3d7d] flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                  <FileText className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-800 transition-colors">
                  e-Relevés & Documents
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Consultez vos relevés mensuels certifiés, attestations de compte et contrats signés.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
                <span>Accéder à mes documents</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Mon épargne */}
            <div 
              onClick={() => onNavigate('savings')}
              className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                  <PiggyBank className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                  Épargne & Livrets
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Livret A, LDDS et PEL : faites fructifier vos liquidités en toute sécurité avec garantie d'État.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
                <span>Simuler mes intérêts</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Mes crédits */}
            <div 
              onClick={() => onNavigate('loans')}
              className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                  <Building2 className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-800 transition-colors">
                  Crédits & Financements
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Prêt personnel, auto écologique ou projet immobilier : simulez vos mensualités au meilleur TAEG.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
                <span>Voir mon prêt en cours</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols on lg) */}
        <div className="lg:col-span-4 space-y-6">

          {/* Mes actions rapides Card */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
            <h2 className="text-sm font-bold text-slate-900 mb-3">
              Mes actions rapides
            </h2>

            <div className="divide-y divide-slate-100 text-xs">
              <button
                onClick={() => onOpenTransfer()}
                className="w-full py-3 flex items-center justify-between text-slate-700 hover:text-blue-800 hover:pl-1 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <Send className="w-4 h-4 text-blue-600 rotate-[-20deg]" />
                  <span className="font-medium">Émettre un virement SEPA</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={onOpenBeneficiary}
                className="w-full py-3 flex items-center justify-between text-slate-700 hover:text-blue-800 hover:pl-1 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <UserPlus className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">Ajouter un bénéficiaire SEPA</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => onOpenRib(primaryAccount)}
                className="w-full py-3 flex items-center justify-between text-slate-700 hover:text-blue-800 hover:pl-1 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">Éditer mon RIB officiel</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => onOpenCardLimits(currentCard)}
                className="w-full py-3 flex items-center justify-between text-slate-700 hover:text-blue-800 hover:pl-1 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">Gérer les plafonds de carte CB</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={onOpenCheckbook}
                className="w-full py-3 flex items-center justify-between text-slate-700 hover:text-blue-800 hover:pl-1 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <CheckSquare className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">Commander un carnet de chèques</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Promotional Banner: French banking app & DSP2 mobile pass */}
          <div className="relative overflow-hidden rounded-2xl bg-[#092247] p-5 text-white shadow-lg shadow-blue-950/20">
            {/* Visual Phone Mockup on the right */}
            <div className="absolute -right-5 -bottom-8 w-32 h-48 bg-slate-900 border-4 border-slate-700 rounded-3xl p-2 shadow-2xl rotate-6 transform opacity-90 hidden sm:block">
              <div className="w-8 h-1 bg-slate-700 rounded-full mx-auto mb-2" />
              <div className="w-full h-4 bg-blue-600 rounded-md mb-2" />
              <div className="w-3/4 h-3 bg-slate-600 rounded-md mb-2" />
              <div className="w-full h-12 bg-slate-800 rounded-lg p-1">
                <div className="w-full h-full border border-blue-400/40 rounded flex items-center justify-center text-[8px] text-blue-300">
                  Pass Sécurité
                </div>
              </div>
            </div>

            <div className="relative z-10 max-w-[210px]">
              <div className="inline-block bg-white/20 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider mb-2">
                Sécurité DSP2
              </div>
              <h3 className="text-sm font-bold text-white leading-tight">
                Gérez votre budget avec l'application mobile
              </h3>
              <p className="text-xs text-blue-200 mt-2 leading-relaxed">
                Validez vos achats en ligne d'un simple geste grâce à la biométrie faciale ou digitale.
              </p>
              
              <button 
                onClick={() => alert("L'application mobile est disponible gratuitement sur l'App Store et Google Play Store !")}
                className="mt-4 px-3.5 py-2 bg-white text-[#092247] hover:bg-blue-50 text-xs font-bold rounded-xl shadow transition-colors flex items-center gap-1.5"
              >
                <span>Découvrir l'application</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Mon conseiller dédié Card: Agence Paris Opéra */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-900">
                Mon conseiller dédié
              </h2>
              <span className="text-[10px] bg-blue-50 text-blue-800 font-semibold px-2 py-0.5 rounded">
                Paris Opéra
              </span>
            </div>

            {/* Advisor Profile */}
            <div className="flex items-center gap-3.5 mb-4">
              <img
                src={advisor.avatarUrl}
                alt={advisor.name}
                referrerPolicy="no-referrer"
                className="w-13 h-13 rounded-full object-cover ring-2 ring-blue-100 shadow-sm"
              />
              <div>
                <h4 className="text-sm font-bold text-slate-900 leading-snug">
                  {advisor.name}
                </h4>
                <p className="text-xs text-slate-500">
                  {advisor.title}
                </p>
                <p className="text-[11px] text-blue-800 font-medium">
                  {advisor.agency}
                </p>
              </div>
            </div>

            {/* Advisor Contacts */}
            <div className="space-y-2.5 text-xs text-slate-600 border-t border-slate-100 pt-3">
              <a 
                href={`tel:${advisor.phone.replace(/\s+/g, '')}`} 
                className="flex items-center gap-2.5 hover:text-blue-700 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{advisor.phone} (Ligne directe agence)</span>
              </a>

              <a 
                href={`mailto:${advisor.email}`} 
                className="flex items-center gap-2.5 hover:text-blue-700 transition-colors truncate"
              >
                <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate">{advisor.email}</span>
              </a>
            </div>

            {/* Action Button: Prendre rendez-vous */}
            <button
              onClick={onOpenAppointment}
              className="w-full mt-4 py-2.5 px-4 border border-[#0f3d7d] text-[#0f3d7d] hover:bg-blue-50 text-xs font-semibold rounded-xl text-center transition-colors"
            >
              Prendre rendez-vous en agence ou visio
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
