import React, { useState, useEffect } from 'react';
import { 
  NavigationTab, 
  BankAccount, 
  BankTransaction, 
  BankCard, 
  Beneficiary, 
  BankDocument, 
  Loan, 
  AdvisorInfo
} from './types';
import { 
  INITIAL_ACCOUNTS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_CARDS, 
  INITIAL_BENEFICIARIES, 
  INITIAL_DOCUMENTS, 
  INITIAL_LOAN, 
  ADVISOR 
} from './data/mockData';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { DashboardView } from './components/DashboardView';
import { AccountsView } from './components/AccountsView';
import { TransfersView } from './components/TransfersView';
import { SavingsView } from './components/SavingsView';
import { CreditsView } from './components/CreditsView';
import { AdvisorView } from './components/AdvisorView';
import { DocumentsView } from './components/DocumentsView';
import { SettingsView } from './components/SettingsView';
import { LoginView } from './components/LoginView';

// Modals
import { RibModal } from './components/modals/RibModal';
import { TransferModal } from './components/modals/TransferModal';
import { CardLimitsModal } from './components/modals/CardLimitsModal';
import { BeneficiaryModal } from './components/modals/BeneficiaryModal';
import { AppointmentModal } from './components/modals/AppointmentModal';
import { TransactionDetailsModal } from './components/modals/TransactionDetailsModal';
import { SpreadPaymentModal } from './components/modals/SpreadPaymentModal';
import { HelpContactModal } from './components/modals/HelpContactModal';
import { CheckbookModal } from './components/modals/CheckbookModal';
import { DownloadProjectModal } from './components/modals/DownloadProjectModal';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem('user_session_authenticated');
    return saved !== null ? saved === 'true' : true;
  });

  const [justLoggedOut, setJustLoggedOut] = useState<boolean>(false);

  // Dynamic account holder name & client ID
  const [accountHolder, setAccountHolder] = useState<string>(() => {
    const saved = localStorage.getItem('account_holder_name');
    if (saved && /kouam|koum|christ/i.test(saved)) {
      localStorage.setItem('account_holder_name', 'Jade Ambre');
      return 'Jade Ambre';
    }
    return saved || 'Jade Ambre';
  });
  const [currentClientId, setCurrentClientId] = useState<string>(() => {
    return localStorage.getItem('saved_client_id') || '84920194';
  });

  const [currentTab, setCurrentTab] = useState<NavigationTab>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');

  // Primary state datasets
  const [accounts, setAccounts] = useState<BankAccount[]>(() => {
    const saved = localStorage.getItem('app_accounts_data');
    return saved ? JSON.parse(saved) : INITIAL_ACCOUNTS;
  });

  const [transactions, setTransactions] = useState<BankTransaction[]>(() => {
    const saved = localStorage.getItem('app_transactions_data');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [cards, setCards] = useState<BankCard[]>(() => {
    const saved = localStorage.getItem('app_cards_data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.map((card: BankCard) => ({
          ...card,
          holder: /kouam|koum|christ/i.test(card.holder || '') ? 'JADE AMBRE' : (card.holder || 'JADE AMBRE'),
        }));
      } catch {
        return INITIAL_CARDS;
      }
    }
    return INITIAL_CARDS;
  });

  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>(() => {
    const saved = localStorage.getItem('app_beneficiaries_data');
    return saved ? JSON.parse(saved) : INITIAL_BENEFICIARIES;
  });

  const [documents] = useState<BankDocument[]>(INITIAL_DOCUMENTS);
  const [loan] = useState<Loan>(INITIAL_LOAN);
  const [advisor] = useState<AdvisorInfo>(ADVISOR);

  // Clean any legacy data on startup
  useEffect(() => {
    try {
      const savedHolder = localStorage.getItem('account_holder_name');
      if (savedHolder && /kouam|koum|christ/i.test(savedHolder)) {
        localStorage.setItem('account_holder_name', 'Jade Ambre');
      }

      const rawUsers = localStorage.getItem('banking_registered_clients');
      if (rawUsers && /kouam|koum|christ/i.test(rawUsers)) {
        const parsed = JSON.parse(rawUsers);
        const cleaned = parsed.map((u: any) => ({
          ...u,
          fullName: /kouam|koum|christ/i.test(u.fullName || '') ? 'Jade Ambre' : u.fullName,
        }));
        localStorage.setItem('banking_registered_clients', JSON.stringify(cleaned));
      }

      const rawCurrent = localStorage.getItem('banking_current_client_profile');
      if (rawCurrent && /kouam|koum|christ/i.test(rawCurrent)) {
        const parsed = JSON.parse(rawCurrent);
        parsed.fullName = 'Jade Ambre';
        localStorage.setItem('banking_current_client_profile', JSON.stringify(parsed));
      }
    } catch {}
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('user_session_authenticated', isAuthenticated.toString());
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('app_accounts_data', JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem('app_transactions_data', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('app_cards_data', JSON.stringify(cards));
  }, [cards]);

  useEffect(() => {
    localStorage.setItem('app_beneficiaries_data', JSON.stringify(beneficiaries));
  }, [beneficiaries]);

  // Modals state
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferFromAccountId, setTransferFromAccountId] = useState<string | undefined>(undefined);

  const [ribAccount, setRibAccount] = useState<BankAccount>(accounts[0]);
  const [isRibModalOpen, setIsRibModalOpen] = useState(false);

  const [activeCardForLimits, setActiveCardForLimits] = useState<BankCard>(cards[0]);
  const [isCardLimitsModalOpen, setIsCardLimitsModalOpen] = useState(false);

  const [isBeneficiaryModalOpen, setIsBeneficiaryModalOpen] = useState(false);
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isCheckbookModalOpen, setIsCheckbookModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const [selectedTx, setSelectedTx] = useState<BankTransaction | null>(null);
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);

  const [spreadTx, setSpreadTx] = useState<BankTransaction | undefined>(undefined);
  const [isSpreadModalOpen, setIsSpreadModalOpen] = useState(false);

  const [legalModalTitle, setLegalModalTitle] = useState<string | null>(null);

  // Auth Handlers
  const handleLogin = (clientId: string, holderName: string) => {
    setCurrentClientId(clientId);
    setAccountHolder(holderName);
    setIsAuthenticated(true);
    setJustLoggedOut(false);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setJustLoggedOut(true);
    setCurrentTab('dashboard');
  };

  // Execute transfer handler
  const handleExecuteTransfer = (data: {
    fromAccountId: string;
    toIban: string;
    beneficiaryName: string;
    amount: number;
    instant: boolean;
    reason: string;
  }) => {
    // 1. Deduct balance from source account
    setAccounts(prev => prev.map(acc => {
      if (acc.id === data.fromAccountId) {
        const newBalance = acc.balance - data.amount;
        return {
          ...acc,
          balance: newBalance,
          availableBalance: newBalance,
        };
      }
      return acc;
    }));

    const sourceAcc = accounts.find(a => a.id === data.fromAccountId) || accounts[0];
    const now = new Date();
    const refCode = `VIR-SEPA-${Date.now().toString().slice(-6)}`;

    // 2. Prepend transaction to history
    const newTx: BankTransaction = {
      id: `tx-${Date.now()}`,
      date: now.toISOString().split('T')[0],
      formattedDate: "Aujourd'hui",
      label: `Virement vers ${data.beneficiaryName}`,
      category: 'transfer',
      amount: -data.amount,
      balanceAfter: sourceAcc.balance - data.amount,
      type: 'debit',
      counterparty: data.beneficiaryName,
      reference: refCode,
    };

    setTransactions(prev => [newTx, ...prev]);
  };

  // Update card settings
  const handleUpdateCard = (updatedCard: BankCard) => {
    setCards(prev => prev.map(c => c.id === updatedCard.id ? updatedCard : c));
  };

  // Add beneficiary
  const handleAddBeneficiary = (newBen: Beneficiary) => {
    setBeneficiaries(prev => [newBen, ...prev]);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f4f7fb] text-slate-800">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onNavigate={setCurrentTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        isAuthenticated={isAuthenticated}
        onLogout={handleLogout}
        onLoginClick={() => {
          setIsAuthenticated(false);
          setJustLoggedOut(false);
        }}
        accountHolder={accountHolder}
        clientId={currentClientId}
      />

      {/* Main Content: Login Screen or Authenticated Customer Area */}
      {!isAuthenticated ? (
        <main className="flex-1">
          <LoginView
            onLogin={handleLogin}
            justLoggedOut={justLoggedOut}
            onOpenHelp={() => setIsHelpModalOpen(true)}
            initialHolderName={accountHolder}
            onOpenDownload={() => setIsDownloadModalOpen(true)}
          />
        </main>
      ) : (
        <div className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 flex">
          {/* Desktop Sidebar Navigation */}
          <Sidebar
            currentTab={currentTab}
            onNavigate={setCurrentTab}
            onOpenHelp={() => setIsHelpModalOpen(true)}
            onLogout={handleLogout}
          />

          {/* Main Content Dynamic Views */}
          <main className="flex-1 py-6 md:pl-2 min-w-0">
            {currentTab === 'dashboard' && (
              <DashboardView
                accounts={accounts}
                transactions={transactions}
                cards={cards}
                advisor={advisor}
                onNavigate={setCurrentTab}
                onOpenTransfer={(accId) => {
                  setTransferFromAccountId(accId);
                  setIsTransferModalOpen(true);
                }}
                onOpenRib={(acc) => {
                  setRibAccount(acc || accounts[0]);
                  setIsRibModalOpen(true);
                }}
                onOpenCardLimits={(card) => {
                  setActiveCardForLimits(card || cards[0]);
                  setIsCardLimitsModalOpen(true);
                }}
                onOpenBeneficiary={() => setIsBeneficiaryModalOpen(true)}
                onOpenAppointment={() => setIsAppointmentModalOpen(true)}
                onOpenCheckbook={() => setIsCheckbookModalOpen(true)}
                onOpenSpreadPayment={(tx) => {
                  setSpreadTx(tx);
                  setIsSpreadModalOpen(true);
                }}
                onSelectTransaction={(tx: BankTransaction) => {
                  setSelectedTx(tx);
                  setIsTxModalOpen(true);
                }}
                accountHolder={accountHolder}
              />
            )}

            {currentTab === 'accounts' && (
              <AccountsView
                accounts={accounts}
                transactions={transactions}
                cards={cards}
                onOpenTransfer={(accId) => {
                  setTransferFromAccountId(accId);
                  setIsTransferModalOpen(true);
                }}
                onOpenRib={(acc) => {
                  setRibAccount(acc || accounts[0]);
                  setIsRibModalOpen(true);
                }}
                onOpenCardLimits={(card) => {
                  setActiveCardForLimits(card || cards[0]);
                  setIsCardLimitsModalOpen(true);
                }}
                onSelectTransaction={(tx: BankTransaction) => {
                  setSelectedTx(tx);
                  setIsTxModalOpen(true);
                }}
                onUpdateCard={handleUpdateCard}
                accountHolder={accountHolder}
              />
            )}

            {currentTab === 'transfers' && (
              <TransfersView
                accounts={accounts}
                beneficiaries={beneficiaries}
                onOpenBeneficiaryModal={() => setIsBeneficiaryModalOpen(true)}
                onExecuteTransfer={handleExecuteTransfer}
                accountHolder={accountHolder}
              />
            )}

            {currentTab === 'savings' && (
              <SavingsView
                accounts={accounts}
                onOpenTransfer={(accId) => {
                  setTransferFromAccountId(accId);
                  setIsTransferModalOpen(true);
                }}
              />
            )}

            {currentTab === 'loans' && (
              <CreditsView
                loan={loan}
                onOpenAppointment={() => setIsAppointmentModalOpen(true)}
              />
            )}

            {currentTab === 'advisor' && (
              <AdvisorView
                advisor={advisor}
                onOpenAppointment={() => setIsAppointmentModalOpen(true)}
                accountHolder={accountHolder}
              />
            )}

            {currentTab === 'documents' && (
              <DocumentsView
                documents={documents}
                accounts={accounts}
                onOpenRib={(acc) => {
                  setRibAccount(acc || accounts[0]);
                  setIsRibModalOpen(true);
                }}
                accountHolder={accountHolder}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsView
                accountHolder={accountHolder}
                onLogout={handleLogout}
              />
            )}
          </main>
        </div>
      )}

      {/* Footer */}
      <Footer
        onOpenLegal={(title) => setLegalModalTitle(title)}
        onOpenHelp={() => setIsHelpModalOpen(true)}
      />

      {/* Modals & Overlays */}
      <RibModal
        isOpen={isRibModalOpen}
        onClose={() => setIsRibModalOpen(false)}
        account={ribAccount}
        accountHolder={accountHolder}
      />

      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        accounts={accounts}
        beneficiaries={beneficiaries}
        defaultFromAccountId={transferFromAccountId}
        onExecuteTransfer={handleExecuteTransfer}
      />

      <CardLimitsModal
        isOpen={isCardLimitsModalOpen}
        onClose={() => setIsCardLimitsModalOpen(false)}
        card={activeCardForLimits}
        onUpdateCard={handleUpdateCard}
      />

      <BeneficiaryModal
        isOpen={isBeneficiaryModalOpen}
        onClose={() => setIsBeneficiaryModalOpen(false)}
        onAddBeneficiary={handleAddBeneficiary}
      />

      <AppointmentModal
        isOpen={isAppointmentModalOpen}
        onClose={() => setIsAppointmentModalOpen(false)}
        advisor={advisor}
      />

      <TransactionDetailsModal
        isOpen={isTxModalOpen}
        onClose={() => setIsTxModalOpen(false)}
        transaction={selectedTx}
      />

      <SpreadPaymentModal
        isOpen={isSpreadModalOpen}
        onClose={() => setIsSpreadModalOpen(false)}
        transaction={spreadTx}
      />

      <HelpContactModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
        onOpenAdvisor={() => {
          setCurrentTab('advisor');
          setIsHelpModalOpen(false);
        }}
      />

      <CheckbookModal
        isOpen={isCheckbookModalOpen}
        onClose={() => setIsCheckbookModalOpen(false)}
      />

      {/* Download Project Modal */}
      <DownloadProjectModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Legal Modal */}
      {legalModalTitle && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-sm">{legalModalTitle}</h3>
              <button onClick={() => setLegalModalTitle(null)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <div className="text-xs text-slate-600 space-y-2 max-h-72 overflow-y-auto">
              <p>Établissement de crédit agréé par l'Autorité de Contrôle Prudentiel et de Résolution (ACPR) sous le code banque 30004.</p>
              <p>Siège social : 14 Boulevard des Italiens, 75009 Paris. Société Anonyme au capital de 1 200 000 000 € - RCS Paris B 498 120 481.</p>
              <p>Sécurité des données : cryptage SSL/TLS 256 bits, authentification forte conforme DSP2, garantie des dépôts par le Fonds de Garantie des Dépôts et de Résolution (FGDR) jusqu’à 100 000 € par déposant.</p>
            </div>
            <div className="flex justify-end pt-2">
              <button
                onClick={() => setLegalModalTitle(null)}
                className="px-5 py-2 bg-[#0f3d7d] text-white text-xs font-semibold rounded-xl"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
